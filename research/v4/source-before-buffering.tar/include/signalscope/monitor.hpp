#pragma once
#include "signalscope/event_store.hpp"
#include "signalscope/lora.hpp"
#include "signalscope/spectrum.hpp"
namespace signalscope {
struct MonitorObserver {
    // 回调可能来自采集/分析/录制不同线程，必须短小且线程安全；GUI 只替换最新快照。
    std::function<void(const Json&)> status;
    std::function<void(const SpectrumFrame&)> spectrum;
    // 录制路径已消费的全局原始样本位置，不等于磁盘实际保存的样本数。
    std::function<void(std::uint64_t)> recording_progress;
};
Json monitor(const Config&,const LoRaConfig&,const RetentionPolicy&,const std::filesystem::path& output,
             const std::filesystem::path& input,const std::function<bool()>& cancelled,const MonitorObserver& observer={});
}

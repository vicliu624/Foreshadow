#pragma once
#include <algorithm>
#include <atomic>
#include <chrono>
#include <complex>
#include <condition_variable>
#include <cstdint>
#include <deque>
#include <filesystem>
#include <fstream>
#include <functional>
#include <mutex>
#include <span>
#include <stdexcept>
#include <string>
#include <vector>
#include <nlohmann/json.hpp>

namespace signalscope {
using Json = nlohmann::json;
using Bytes = std::vector<std::uint8_t>;
// 保留采集失败时的结构化统计，界面仍显示简短错误原因。
class SourceError : public std::runtime_error {
public:
    SourceError(const std::string& message,Json report) : std::runtime_error(message),details(std::move(report)) {}
    Json details;
};
struct Config {
    std::uint32_t rate = 2000000;
    std::uint32_t frequency = 470500000;
    int gain_tenths = 197;
    bool auto_gain = false;
    std::uint32_t device = 0;
    std::size_t block_bytes = 65536;
    std::size_t queue_blocks = 64;
    double seconds = 10;
    double settle_seconds = 0.1;
    void validate() const;
};
std::uint64_t sample_count(double seconds, std::uint32_t rate);
std::string utc_now();
void write_json(const std::filesystem::path&, const Json&);

// 满队列明确拒绝，调用者必须停止或记录缺口；绝不默默覆盖。
template<class T> class BoundedQueue {
public:
    explicit BoundedQueue(std::size_t capacity) : capacity_(capacity) {
        if (!capacity) throw std::invalid_argument("队列容量必须大于零");
    }
    bool try_push(T value) {
        std::lock_guard lock(mutex_);
        if (closed_ || queue_.size() == capacity_) return false;
        queue_.push_back(std::move(value));
        high_water_ = std::max(high_water_, queue_.size());
        cv_.notify_one(); return true;
    }
    bool pop(T& value) {
        std::unique_lock lock(mutex_);
        cv_.wait(lock, [&]{return closed_ || !queue_.empty();});
        if (queue_.empty()) return false;
        value = std::move(queue_.front()); queue_.pop_front(); return true;
    }
    bool try_pop(T& value) {
        std::lock_guard lock(mutex_);
        if(queue_.empty())return false;
        value=std::move(queue_.front());queue_.pop_front();return true;
    }
    void close() { std::lock_guard lock(mutex_); closed_ = true; cv_.notify_all(); }
    std::size_t high_water() const { std::lock_guard lock(mutex_); return high_water_; }
private:
    const std::size_t capacity_;
    mutable std::mutex mutex_;
    std::condition_variable cv_;
    std::deque<T> queue_;
    std::size_t high_water_ = 0;
    bool closed_ = false;
};

struct PowerStats {
    std::uint64_t pairs = 0, clipped_pairs = 0;
    double energy = 0, sum_i = 0, sum_q = 0;
    void add(std::span<const std::uint8_t>);
    Json json() const;
};
class Recorder {
public:
    Recorder(const std::filesystem::path& directory, const Config&, const std::string& source);
    void append(std::span<const std::uint8_t>);
    void finish(const std::string& status, const Json& extra = Json::object());
    void annotate(const Json& annotation);
    std::uint64_t pairs() const { return pairs_; }
    ~Recorder();
private:
    void publish();
    std::filesystem::path directory_;
    std::ofstream data_;
    Json meta_;
    std::uint64_t pairs_ = 0;
    bool finished_ = false;
};

struct ReplayInfo {
    std::filesystem::path data_path;
    Json metadata;
    std::uint32_t rate = 0;
    double frequency = 0;
    std::uint64_t pairs = 0;
};
ReplayInfo inspect_recording(const std::filesystem::path& metadata);
using BlockSink = std::function<void(std::span<const std::uint8_t>, std::uint64_t)>;
void replay(const ReplayInfo&, std::uint64_t first, std::uint64_t count,
            double speed, std::size_t block_bytes, const BlockSink&,
            const std::function<bool()>& cancelled);
Json list_devices();
Json probe_device(std::uint32_t index);
Json capture_rtlsdr(const Config&, Recorder&, const std::function<bool()>& cancelled);
Json stream_rtlsdr(const Config&, const BlockSink&, const std::function<bool()>& cancelled);
}

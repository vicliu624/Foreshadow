"""对失败射频用例做有限原始采集；结束后恢复正常接收，不使用已知参数辅助盲检测。"""
import argparse
import json
import os
from pathlib import Path
import shlex
import subprocess
import time
from pager_tx import PagerTx
from rf_test_matrix import receiver_snapshot

def remote(host,code):
    p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5',host,'python3','-'],input=code,capture_output=True,text=True,encoding='utf-8',timeout=15,check=True)
    return p.stdout

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report',required=True);parser.add_argument('--case',required=True);parser.add_argument('--output',required=True)
    parser.add_argument('--receiver',default='vicliu@192.168.50.92');parser.add_argument('--port',default='COM11')
    parser.add_argument('--power',type=int,choices=(-9,-6,-3,0))
    parser.add_argument('--rate',type=int,choices=(1750000,1875000,2000000))
    args=parser.parse_args();report=json.loads(Path(args.report).read_text(encoding='utf-8'))
    case=next(item['case'] for item in report['cases'] if item['case']['name']==args.case)
    if args.power is not None:case['power']=args.power
    config={key:case[key] for key in ('frequency','bandwidth','sf','cr','power','preamble','sync','inverted')}
    before=receiver_snapshot(args.receiver,'/home/vicliu/SignalScope-events')
    rx=before['status']['receiver_configuration']
    capture_rate=args.rate or rx['sample_rate_hz']
    local=Path(args.output).resolve();local.mkdir(parents=True,exist_ok=False)
    temporary='/tmp/signalscope-rf-diag-'+str(time.time_ns())
    capture=None;paused=False;failure=None;result={'case':case,'receiver_configuration':rx,'capture_rate_hz':capture_rate,'source':'controlled_tx_raw_capture_for_diagnosis','created_unix_seconds':time.time()}
    with PagerTx(args.port) as tx:
        tx.configure(**config)
        try:
            code=f'''from pathlib import Path
import os,json,signal,time,shutil
for old in Path('/tmp').glob('signalscope-rf-diag-*'):
    marker=old/'owner.json'
    if old.is_symlink() or not marker.is_file():continue
    value=json.loads(marker.read_text())
    if value.get('owner')=='signalscope-rf-diagnostic' and value.get('expires_unix_seconds',1e30)<time.time():shutil.rmtree(old)
manifest=Path('/home/vicliu/.local/share/signalscope/install-manifest.json')
pid=json.loads(manifest.read_text())['receiver_pid']
exe=Path(f'/proc/{{pid}}/exe')
if exe.exists():
    if exe.resolve()!=Path('/home/vicliu/.local/bin/signalscope-gui'):raise RuntimeError('接收程序 PID 不匹配')
    os.kill(pid,signal.SIGTERM)
    for _ in range(100):
        if not Path(f'/proc/{{pid}}').exists():break
        time.sleep(.02)
path=Path({temporary!r});path.mkdir()
(path/'owner.json').write_text(json.dumps({{'owner':'signalscope-rf-diagnostic','expires_unix_seconds':time.time()+120}}))
print('receiver paused for 3-second raw test')
'''
            remote(args.receiver,code)
            paused=True
            command=['/home/vicliu/.local/bin/signalscope','capture','--output',temporary+'/capture','--seconds','3',
                     '--frequency',str(rx['frequency_hz']),'--rate',str(capture_rate),
                     '--gain','auto' if rx['auto_gain'] else str(rx['gain_tenths_db']/10)]
            with (local/'capture.log').open('w',encoding='utf-8') as log:
                capture=subprocess.Popen(['ssh',args.receiver,shlex.join(command)],stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
                for _ in range(20):
                    if capture.poll() is not None:raise RuntimeError('原始采集提前退出，见 capture.log')
                    size=int(remote(args.receiver,f"from pathlib import Path\np=Path({temporary+'/capture/capture.sigmf-data'!r})\nprint(p.stat().st_size if p.exists() else 0)"))
                    if size>=262144:break
                    time.sleep(.05)
                else:raise RuntimeError('未等到真实采样数据，未发射')
                result['tx']=tx.transmit(int(time.time()*1000)&0xffffffff,case['length'])
                code=capture.wait(timeout=10);result['capture_returncode']=code
                if code:raise RuntimeError('采集失败，见 capture.log')
        except BaseException as error:
            failure=error;result['error']=str(error);result['partial_transmission']=getattr(tx,'last_transmission',{})
        finally:
            if capture and capture.poll() is None:
                try:capture.wait(timeout=6)
                except subprocess.TimeoutExpired:capture.terminate();capture.wait(timeout=3)
            if capture:result['capture_returncode']=capture.returncode
            code=f'''from pathlib import Path
import json,os,subprocess,time
manifest=Path('/home/vicliu/.local/share/signalscope/install-manifest.json')
env=dict(os.environ,XDG_RUNTIME_DIR='/run/user/1000',WAYLAND_DISPLAY='wayland-0',QT_QPA_PLATFORM='wayland',DBUS_SESSION_BUS_ADDRESS='unix:path=/run/user/1000/bus')
p=subprocess.Popen(['/home/vicliu/.local/bin/signalscope-gui','--frequency',str({rx['frequency_hz']}/1e6),'--gain',str({rx['gain_tenths_db']}/10),'--output','/home/vicliu/SignalScope-events','--autostart'],env=env,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
state=json.loads(manifest.read_text());state['receiver_pid']=p.pid;manifest.write_text(json.dumps(state,indent=2))
print(p.pid)
'''
            if paused:result['restored_receiver_pid']=int(remote(args.receiver,code).strip())
            (local/'trial.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    try:
        subprocess.run(['scp','-r',args.receiver+':'+temporary+'/capture',str(local)],check=True)
    except subprocess.CalledProcessError:
        if not failure:raise
    cleanup=f'''from pathlib import Path
import json,shutil
path=Path({temporary!r})
if path.resolve()!=path or not str(path).startswith('/tmp/signalscope-rf-diag-') or path.is_symlink():raise RuntimeError('非法清理路径')
if json.loads((path/'owner.json').read_text())['owner']!='signalscope-rf-diagnostic':raise RuntimeError('目录标识不匹配')
shutil.rmtree(path)
'''
    remote(args.receiver,cleanup)
    if failure:raise RuntimeError('诊断发射或采集失败，接收器已恢复；详情见 trial.json') from failure
    print(json.dumps({'output':str(local),'case':case['name'],'capture_returncode':result['capture_returncode'],'restored_receiver_pid':result['restored_receiver_pid']},ensure_ascii=False))
if __name__=='__main__':main()

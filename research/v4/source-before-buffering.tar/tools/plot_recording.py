"""绘制已录制 I/Q 的研究图；仅离线分析，不发射，不修改原始文件。"""
import argparse
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--input',required=True)
parser.add_argument('--output',required=True)
parser.add_argument('--analysis')
args=parser.parse_args()
meta_path=Path(args.input)
meta=json.loads(meta_path.read_text(encoding='utf-8'))
global_meta=meta['global']
result=global_meta.get('signalscope:result',{})
if args.analysis:
    result={'events':json.loads(Path(args.analysis).read_text(encoding='utf-8'))['events'],'stream_first_sample':0}
event=next(e for e in result['events'] if e['evidence_level']=='lora_structure_match')
rate=float(global_meta['core:sample_rate'])
receiver=float(meta['captures'][0]['core:frequency'])
data_path=meta_path.with_suffix('.sigmf-data')
if data_path.stat().st_size>64*1024*1024:raise RuntimeError('研究图支持的原始数据上限为 64 MiB，请先裁剪')
raw=np.fromfile(data_path,dtype=np.uint8).reshape(-1,2)
iq=((raw[:,0].astype(np.float32)-127.5)+1j*(raw[:,1].astype(np.float32)-127.5))/128
bw=float(event['bandwidth_hz'])
sf=int(event['sf_candidate'])
n=round(rate*2**sf/bw)
sfd=int(event['sfd_start_sample'])-int(result['stream_first_sample'])
for path in [Path('C:/Windows/Fonts/msyh.ttc'),Path('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')]:
    if path.exists():
        font_manager.fontManager.addfont(str(path));plt.rcParams['font.family']=font_manager.FontProperties(fname=str(path)).get_name();break
plt.rcParams['axes.unicode_minus']=False
fig,axes=plt.subplots(2,2,figsize=(14,9),layout='constrained')
source=global_meta.get('signalscope:source','external-unknown')
origin='真实射频录制研究' if source=='rtlsdr' or source.startswith('automatic-lora-event:live-rtlsdr') else '录制 I/Q 研究'
fig.suptitle(origin+'：LoRa 前导码结构匹配（未解码协议/载荷）',fontsize=17)

first=max(0,sfd-24*n)
last=min(len(iq),sfd+35*n)
size=min(1024,1<<max(5,(max(32,n//4).bit_length()-1)))
stft_size=size
segment=iq[first:last]
count=len(segment)//size
window=np.hanning(size)
blocks=segment[:count*size].reshape(count,size)
power=np.abs(np.fft.fftshift(np.fft.fft(blocks*window,axis=1),axes=1))**2/(rate*np.sum(window**2))
freq=receiver+np.fft.fftshift(np.fft.fftfreq(size,1/rate))
selection=np.abs(freq-event['center_frequency_hz'])<bw*.8
image=axes[0,0].imshow(10*np.log10(np.maximum(power[:,selection],1e-16)).T,origin='lower',aspect='auto',
    extent=[first/rate,(first+count*size)/rate,freq[selection][0]/1e6,freq[selection][-1]/1e6],vmin=-115,vmax=-45,cmap='magma')
axes[0,0].axvline(sfd/rate,color='cyan',ls='--',lw=1,label='估计 SFD 起点')
axes[0,0].set(title='原始 I/Q 时频图',xlabel='录制内时间 / 秒',ylabel='接收频率 / MHz')
axes[0,0].ticklabel_format(axis='y',useOffset=False)
axes[0,0].legend(fontsize=8)
fig.colorbar(image,ax=axes[0,0],label='数字域功率谱密度 / dBFS/Hz')

start=max(0,sfd-3*n)
symbol=iq[start:start+n]
if len(symbol)!=n:raise RuntimeError('缺少用于研究的完整前导码符号')
t=np.arange(n)/rate
reference=np.exp(2j*np.pi*(-bw*t/2+bw*t*t/(2*(2**sf/bw))))
if event.get('iq_inverted'):symbol=np.conj(symbol)
dechirped=np.fft.fftshift(np.fft.fft(symbol*np.conj(reference)))
offsets=np.fft.fftshift(np.fft.fftfreq(n,1/rate))
physical=receiver+(-offsets if event.get('iq_inverted') else offsets)
amplitude=np.abs(dechirped)**2/n**2
order=np.argsort(physical)
axes[0,1].plot(physical[order]/1e6,10*np.log10(np.maximum(amplitude[order],1e-14)),lw=.8)
peak=int(np.argmax(amplitude))
axes[0,1].axvline(physical[peak]/1e6,color='tab:orange',lw=1,alpha=.7,label=f"最大峰 {physical[peak]/1e6:.6f} MHz")
axes[0,1].plot(physical[peak]/1e6,10*np.log10(max(amplitude[peak],1e-14)),'o',color='tab:orange',ms=3)
axes[0,1].set_xlim((event['center_frequency_hz']-bw*.7)/1e6,(event['center_frequency_hz']+bw*.7)/1e6)
axes[0,1].set(title='一个前导码符号：Dechirp + FFT',xlabel='匹配频率 / MHz',ylabel='FFT 分量 / dBFS')
axes[0,1].ticklabel_format(axis='x',useOffset=False)
axes[0,1].grid(alpha=.25)
axes[0,1].legend(fontsize=8)

estimate=iq[max(0,sfd-6*n):max(0,sfd-2*n)]
length=len(estimate)
transform=np.fft.fft(estimate,n=1<<(2*length-1).bit_length())
correlation=np.abs(np.fft.ifft(np.abs(transform)**2)[:length])
correlation=correlation/np.arange(length,0,-1)/np.mean(np.abs(estimate)**2)
period=None
for lag in range(513,length//2):
    if correlation[lag]>.8 and correlation[lag]>=correlation[lag-1] and correlation[lag]>correlation[lag+1]:
        period=lag/rate;break
size=min(2048,1<<max(4,(max(16,length//2).bit_length()-1)))
psd_size=size
count=len(estimate)//size
window=np.hanning(size)
psd=np.mean(np.abs(np.fft.fftshift(np.fft.fft(estimate[:count*size].reshape(count,size)*window,axis=1),axes=1))**2/(rate*np.sum(window**2)),axis=0)
freq=receiver+np.fft.fftshift(np.fft.fftfreq(size,1/rate))
axes[1,0].plot(freq/1e6,10*np.log10(np.maximum(psd,1e-16)),lw=.8)
axes[1,0].set_xlim((event['center_frequency_hz']-bw)/1e6,(event['center_frequency_hz']+bw)/1e6)
axes[1,0].set(title='前导码时段功率谱（含环境信号，未 RF 校准）',xlabel='接收频率 / MHz',ylabel='数字域 PSD / dBFS/Hz')
axes[1,0].ticklabel_format(axis='x',useOffset=False)
axes[1,0].grid(alpha=.25)
roi=np.abs(freq-event['center_frequency_hz'])<=bw*.6
occupied=np.where(roi,np.maximum(psd-np.median(psd),0),0)
if np.sum(occupied)<=0:raise RuntimeError('候选频段内没有可测量的超额功率')
cumulative=np.cumsum(occupied)/np.sum(occupied)
lo=freq[np.searchsorted(cumulative,.01)]
hi=freq[min(len(freq)-1,np.searchsorted(cumulative,.99))]
axes[1,0].axvspan(lo/1e6,hi/1e6,alpha=.15,color='teal',label='候选频段内约 98% 功率')
axes[1,0].legend(fontsize=8)

axes[1,1].axis('off')
axes[1,1].text(.03,.97,
    f"观测中心估计：{event['center_frequency_hz']/1e6:.6f} MHz\n"
    f"调制带宽候选：{bw/1000:g} kHz\n扩频因子候选：SF{sf}\n"+
    (f"原始前导码相关周期：{period*1000:.3f} 毫秒\n" if period else "原始相关周期：不可可靠估计\n")+
    f"局部 PSD 频带中点：{(lo+hi)/2/1e6:.6f} MHz\n"
    f"局部 98% 功率宽度：{(hi-lo)/1000:.1f} kHz\n"
    "PSD 测量限于候选中心 ±0.6×BW，\n不是独立的 LoRa 带宽证明。\n"
    f"录制长度：{len(iq)/rate:.5f} 秒\n原始样本：{len(iq):,} 对 I/Q\n\n"
    "结构证据：\n重复上 Chirp + 同步 Chirp 网格\n两个下 Chirp + 四分之一下 Chirp结束\n\n"
    "识别得分不是概率；频率未做 RF 标定。\n不由此判断 Meshtastic、LoRaWAN 或设备身份。",
    va='top',fontsize=11,linespacing=1.35)
output=Path(args.output);output.parent.mkdir(parents=True,exist_ok=True)
fig.savefig(output,dpi=140)
print(json.dumps({'output':str(output),'psd_band_center_hz':(lo+hi)/2,'psd_98_percent_bandwidth_hz':hi-lo,
                  'stft_fft_samples':stft_size,'psd_fft_samples':psd_size,
                  'psd_scope':'candidate_center_plus_minus_0.6_bw; includes background signals; not independent BW evidence',
                  'dechirp_peak_hz':float(physical[int(np.argmax(amplitude))]),'raw_correlation_period_seconds':period,
                  'sf_from_period_and_bw':float(np.log2(period*bw)) if period else None},ensure_ascii=False))

"""测量固定 I/Q 录制的盲检吞吐；结果不是现场误报率或射频灵敏度。"""
import argparse
import json
from pathlib import Path
import subprocess
import time

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--exe', required=True)
parser.add_argument('--input', required=True)
parser.add_argument('--output', required=True)
parser.add_argument('--threshold', type=float, action='append', required=True)
parser.add_argument('--workers', type=int, choices=(1, 2, 3, 4), default=3)
args = parser.parse_args()
meta = Path(args.input)
description = json.loads(meta.read_text(encoding='utf-8'))
duration = meta.with_suffix('.sigmf-data').stat().st_size / 2 / description['global']['core:sample_rate']
report = {'duration_seconds': duration, 'trials': []}
for threshold in args.threshold:
    started = time.monotonic()
    result = subprocess.run([args.exe, 'detect', '--input', str(meta), '--threshold-db', str(threshold), '--workers', str(args.workers)],
                            capture_output=True, encoding='utf-8', check=True)
    elapsed = time.monotonic() - started
    decoded = json.loads(result.stdout)
    trial = {'threshold_db': threshold, 'elapsed_seconds': elapsed,
             'workers': args.workers,
             'processing_seconds': decoded.get('processing_seconds'),
             'search_work': decoded.get('search_work', []),
             'wall_seconds_per_iq_second': elapsed / duration,
             'structure_matches': [e for e in decoded['events'] if e['evidence_level'] == 'lora_structure_match']}
    report['trials'].append(trial)
    Path(args.output).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({key: value for key, value in trial.items() if key != 'search_work'}, ensure_ascii=False), flush=True)

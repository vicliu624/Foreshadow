#include "signalscope/monitor.hpp"
#include <exception>
#include <thread>
#include <optional>
#ifdef __linux__
#include <sys/resource.h>
#include <unistd.h>
#endif

namespace signalscope {
namespace {
struct Block { std::uint64_t first; Bytes bytes; };
void shift_event(Json& event,std::uint64_t origin) {
    for(const auto* key:{"first_observed_sample","confirmed_at_sample","sfd_start_sample","sfd_end_sample"})
        if(event.contains(key)) event[key]=event[key].get<std::uint64_t>()+origin;
}
}
Json monitor(const Config& cfg,const LoRaConfig& lc,const RetentionPolicy& retention,const std::filesystem::path& output,
             const std::filesystem::path& input,const std::function<bool()>& cancelled,const MonitorObserver& observer) {
    cfg.validate();
    if(lc.rate!=cfg.rate || lc.receiver_frequency!=cfg.frequency) throw std::invalid_argument("检测与采集配置不一致");
    auto detector=std::make_unique<LoRaDetector>(lc);
    EventStore store(output,cfg,retention);
    BoundedQueue<Block> queue(cfg.queue_blocks);
    const auto recording_capacity=std::max<std::size_t>(1,(32ULL*1024*1024)/cfg.block_bytes);
    BoundedQueue<Block> recording_queue(recording_capacity);
    BoundedQueue<Json> result_queue(16);std::mutex store_mutex;
    std::mutex status_mutex;std::optional<Json> pending_status;
    std::atomic<std::uint64_t> dropped_pairs=0,source_pairs=0,dropped_results=0,diagnostic_events_not_recorded=0;
    std::atomic<std::uint64_t> recorded_pairs=0;
    std::atomic<std::uint64_t> dropped_result_events=0;
    std::atomic<bool> analysis_failed=false,writer_failed=false;
    std::exception_ptr failure,writer_failure;
    Json latest=Json::array(),candidates=Json::array(),last_status=Json::object(),source_result;
    std::string failure_text;
    const auto started=std::chrono::steady_clock::now();
    Spectrometer spectrometer;
    std::mutex transient_mutex;Json transient;
    std::vector<float> spectral_baseline;unsigned baseline_frames=0;
    double power_baseline=0;
    std::jthread analysis([&]{
        std::uint64_t expected=0,origin=0,processed=0,gaps=0;
        auto last_report=std::chrono::steady_clock::now()-std::chrono::seconds(5);
        auto last_disk=last_report;
#ifdef __linux__
        double last_cpu=0;auto last_load_time=started;
#endif
        auto publish=[&](const std::string& state,bool persist=true){
            Json storage;bool storage_stale=false;
            {std::unique_lock lock(store_mutex,std::try_to_lock);
             if(lock.owns_lock())storage=store.status();
             else {storage=last_status.value("storage",Json::object());storage_stale=true;}}
            const auto captured=source_pairs.load(),recorded=recorded_pairs.load();
            last_status={{"state",state},{"source",input.empty()?"live-rtlsdr":"recorded"},
                {"source_input",input.string()},{"source_pairs",captured},{"processed_pairs",processed},
                {"analysis_dropped_pairs",dropped_pairs.load()},{"analysis_gaps",gaps},
                {"analysis_queue_high_water_blocks",queue.high_water()},{"result_dropped_groups",dropped_results.load()},{"capture_pipeline","independent_capture_writer_v3"},
                {"recording_processed_pairs",recorded},{"recording_queue_high_water_blocks",recording_queue.high_water()},
                {"recording_queue_capacity_bytes",recording_capacity*cfg.block_bytes},{"storage_status_stale",storage_stale},
                {"recording_lag_seconds",double(captured>recorded?captured-recorded:0)/cfg.rate},
                {"result_queue_policy","recordable_events_only"},{"diagnostic_events_not_recorded",diagnostic_events_not_recorded.load()},
                {"result_dropped_events",dropped_result_events.load()},
                {"analysis_lag_seconds",double(source_pairs.load()>expected?source_pairs.load()-expected:0)/cfg.rate},
                {"elapsed_seconds",std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count()},
                {"updated_utc",utc_now()},{"storage",storage},{"recent_lora_events",latest},{"recent_candidates",candidates},
                {"receiver_configuration",{{"frequency_hz",cfg.frequency},{"sample_rate_hz",cfg.rate},{"gain_tenths_db",cfg.gain_tenths},{"auto_gain",cfg.auto_gain},{"search_width_hz",lc.search_width}}},
                {"detector",{{"algorithm","dechirp-fft-structure-v4"},{"bandwidth_hz",lc.bandwidth},
                    {"preamble_threshold_db",lc.peak_to_mean_db},{"downchirp_threshold_db",lc.peak_to_mean_db-2},
                    {"sf_min",lc.sf_min},{"sf_max",lc.sf_max},{"time_phases",lc.time_phases},{"workers",lc.workers},
                    {"normal_iq",lc.normal_iq},{"inverted_iq",lc.inverted_iq},
                    {"bandwidth_candidates_hz",lc.bandwidth_candidates.empty()?std::vector<double>{lc.bandwidth}:lc.bandwidth_candidates},
                    {"scores_calibrated",false}}}};
#ifdef __linux__
            rusage usage{};
            if(getrusage(RUSAGE_SELF,&usage)==0) {
                const double cpu=usage.ru_utime.tv_sec+usage.ru_utime.tv_usec/1e6+usage.ru_stime.tv_sec+usage.ru_stime.tv_usec/1e6;
                const auto now=std::chrono::steady_clock::now();const auto elapsed=std::chrono::duration<double>(now-last_load_time).count();
                last_status["cpu_percent_of_machine"]=elapsed>0 && state!="starting"?100*(cpu-last_cpu)/elapsed/std::max(1u,std::thread::hardware_concurrency()):0;
                last_status["peak_rss_bytes"]=std::uint64_t(usage.ru_maxrss)*1024;last_cpu=cpu;last_load_time=now;
            }
            std::ifstream memory("/proc/self/statm");std::uint64_t virtual_pages=0,resident_pages=0;
            if(memory>>virtual_pages>>resident_pages)last_status["rss_bytes"]=resident_pages*static_cast<std::uint64_t>(sysconf(_SC_PAGESIZE));
#endif
            if(!failure_text.empty()) last_status["error"]=failure_text;
            if(persist) {{std::lock_guard lock(status_mutex);pending_status=last_status;}last_disk=std::chrono::steady_clock::now();}
            if(observer.status) observer.status(last_status);
        };
        try {
            publish("starting");
            Block block;std::optional<Block> deferred;
            for(;;) {
                if(deferred){block=std::move(*deferred);deferred.reset();}
                else if(!queue.pop(block))break;
                if(cancelled()) break;
                // 只合并已经到达的连续块，不等待凑批，也不扩容队列。
                // 遇到缺口留待下一轮重置，不能把不连续样本拼在一起。
                Block next;
                while(block.bytes.size()+cfg.block_bytes<=262144 && queue.try_pop(next)) {
                    if(next.first!=block.first+block.bytes.size()/2){deferred=std::move(next);break;}
                    block.bytes.insert(block.bytes.end(),next.bytes.begin(),next.bytes.end());
                }
                if(block.first!=expected) {
                    ++gaps; origin=block.first;
                    detector->reset();
                }
                detector->feed(block.bytes,block.first-origin);
                auto events=detector->take_events();
                if(retention.diagnostic_candidates) {
                    std::lock_guard lock(transient_mutex);
                    if(!transient.is_null() && transient["confirmed_at_sample"].get<std::uint64_t>()<=block.first+block.bytes.size()/2) {
                        auto event=std::move(transient);transient=nullptr;
                        // 已经是全局样本位置；下面统一加 origin 前先转为当前局部索引。
                        if(event["first_observed_sample"].get<std::uint64_t>()>=origin) {
                            event["first_observed_sample"]=event["first_observed_sample"].get<std::uint64_t>()-origin;
                            event["confirmed_at_sample"]=event["confirmed_at_sample"].get<std::uint64_t>()-origin;
                            events.push_back(std::move(event));
                        }
                    }
                }
                Json record_events=Json::array();
                for(auto& event:events) {
                    shift_event(event,origin);
                    event["source"]=input.empty()?"live-rtlsdr":"recorded";
                    if(event.value("evidence_level",std::string())=="lora_structure_match") {
                        latest.push_back(event); if(latest.size()>32) latest.erase(latest.begin());
                    } else if(event.value("evidence_level",std::string())=="chirp_probe" || event.value("evidence_level",std::string())=="energy_transient") {
                        candidates.push_back(event);if(candidates.size()>8)candidates.erase(candidates.begin());
                    }
                    // 常规模式的探针只用于状态显示，不能堵住录制触发队列。
                    if(retention.diagnostic_candidates || event.value("evidence_level",std::string())=="lora_structure_match")
                        record_events.push_back(std::move(event));
                    else ++diagnostic_events_not_recorded;
                }
                if(!record_events.empty()&&!result_queue.try_push(std::move(record_events)))++dropped_results;
                processed+=block.bytes.size()/2; expected=block.first+block.bytes.size()/2;
                if(std::chrono::steady_clock::now()-last_report>=std::chrono::seconds(1)) {
                    publish("listening",std::chrono::steady_clock::now()-last_disk>=std::chrono::seconds(5)); last_report=std::chrono::steady_clock::now();
                }
            }
            publish("analysis_finished");
        } catch(const std::exception& e) {
            failure=std::current_exception(); failure_text=e.what(); analysis_failed=true;
            try {publish("error");} catch(...) {}
        }
    });
    std::exception_ptr source_failure;
    auto drain_results=[&]{
        Json events=Json::array(),group;
        for(int n=0;n<16&&result_queue.try_pop(group);++n)
            for(auto& event:group){if(events.size()<4096)events.push_back(std::move(event));else ++dropped_result_events;}
        return events;
    };
    std::jthread writer([&]{
        Json future=Json::array();
        auto eligible=[&](std::uint64_t end){
            for(auto& event:drain_results()) {
                if(future.size()<4096)future.push_back(std::move(event));else ++dropped_result_events;
            }
            Json ready=Json::array(),later=Json::array();
            for(auto& event:future) {
                if(event.at("confirmed_at_sample").get<std::uint64_t>()<=end)ready.push_back(std::move(event));
                else later.push_back(std::move(event));
            }
            future=std::move(later);return ready;
        };
        auto persist_status=[&]{
            std::optional<Json> status;
            {std::lock_guard lock(status_mutex);status=std::move(pending_status);pending_status.reset();}
            if(status)write_json(output/"monitor-status.json",*status);
        };
        try {
            Block block;
            while(recording_queue.pop(block)) {
                const auto end=block.first+block.bytes.size()/2;
                auto events=eligible(end);
                {std::lock_guard lock(store_mutex);store.feed(block.bytes,block.first,events);}
                recorded_pairs=end;
                if(observer.recording_progress)observer.recording_progress(end);
                persist_status();
            }
            // 主线程先等待分析结束，再关闭录制队列，故此处可收齐末尾结果。
            auto events=eligible(recorded_pairs.load());
            {std::lock_guard lock(store_mutex);store.feed({},recorded_pairs.load(),events);}
            dropped_result_events+=future.size();
            persist_status();
        } catch(...) {writer_failure=std::current_exception();writer_failed=true;}
    });
    auto last_spectrum=started-std::chrono::seconds(1);
    try {
        const auto sink=[&](std::span<const std::uint8_t> bytes,std::uint64_t first){
            if(writer_failed)throw std::runtime_error("录制线程失败，停止采集");
            source_pairs=first+bytes.size()/2;
            if((observer.spectrum || retention.diagnostic_candidates) && std::chrono::steady_clock::now()-last_spectrum>=std::chrono::milliseconds(250)) {
                const auto frame=spectrometer.measure(bytes,first,cfg.rate,cfg.frequency);
                if(observer.spectrum)observer.spectrum(frame);
                if(retention.diagnostic_candidates && !frame.bins_dbfs.empty()) {
                    if(spectral_baseline.empty()) {
                        spectral_baseline.resize(frame.bins_dbfs.size());
                        for(std::size_t i=0;i<frame.bins_dbfs.size();++i)spectral_baseline[i]=static_cast<float>(std::pow(10.0,frame.bins_dbfs[i]/10.0));
                        power_baseline=frame.power_dbfs;
                    }
                    double maximum_rise=-100;std::size_t maximum_bin=0;unsigned adjacent=0;bool narrow_rise=false;
                    for(std::size_t i=0;i<frame.bins_dbfs.size();++i) {
                        const double linear=std::pow(10.0,frame.bins_dbfs[i]/10.0);
                        const double rise=10*std::log10(linear/std::max<double>(spectral_baseline[i],1e-14));
                        if(rise>maximum_rise){maximum_rise=rise;maximum_bin=i;}
                        adjacent=rise>12?adjacent+1:0;if(adjacent>=3)narrow_rise=true;
                        const auto alpha=baseline_frames<8?1.0/double(baseline_frames+1):.02;
                        spectral_baseline[i]=static_cast<float>((1-alpha)*spectral_baseline[i]+alpha*linear);
                    }
                    if(baseline_frames>=8 && (frame.power_dbfs-power_baseline>3 || narrow_rise)) {
                        std::lock_guard lock(transient_mutex);
                        transient={{"evidence_level","energy_transient"},{"first_observed_sample",first},{"confirmed_at_sample",first+std::min<std::size_t>(1024,bytes.size()/2)},
                            {"spectrum_peak_frequency_hz",cfg.frequency-cfg.rate/2.0+maximum_bin*double(cfg.rate)/frame.bins_dbfs.size()},
                            {"energy_rise_db",std::max(maximum_rise,frame.power_dbfs-power_baseline)},
                            {"note","仅用于有界临时诊断，能量变化不等于 LoRa"}};
                    }
                    power_baseline=.98*power_baseline+.02*frame.power_dbfs;++baseline_frames;
                }
                last_spectrum=std::chrono::steady_clock::now();
            }
            // 写盘、淘汰和元数据均在独立线程；满队列明确停止，绝不覆盖原始样本。
            if(!recording_queue.try_push({first,Bytes(bytes.begin(),bytes.end())}))
                throw std::runtime_error("有界录制缓冲已满，停止采集；原始尾部不完整");
            if(!queue.try_push({first,Bytes(bytes.begin(),bytes.end())})) dropped_pairs+=bytes.size()/2;
        };
        const auto stop=[&]{return cancelled() || analysis_failed.load() || writer_failed.load();};
        if(input.empty()) source_result=stream_rtlsdr(cfg,sink,stop);
        else {
            const auto info=inspect_recording(input);
            replay(info,0,info.pairs,1,cfg.block_bytes,sink,stop);
            source_result={{"backend","recorded"},{"pairs",source_pairs.load()}};
        }
    } catch(const SourceError& e) {source_result=e.details;source_failure=std::current_exception();}
      catch(...) {source_failure=std::current_exception();}
    queue.close(); analysis.join();
    recording_queue.close();writer.join();
    if(writer_failure)source_failure=writer_failure;
    try {
        store.finish(failure?"analysis_error":source_failure?"source_error":cancelled()?"monitor_cancelled":"monitor_stopped");
        last_status["storage"]=store.status();
        last_status["state"]=(failure||source_failure)?"error":"stopped";
        last_status["result_dropped_groups"]=dropped_results.load();
        last_status["result_dropped_events"]=dropped_result_events.load();
        last_status["recording_processed_pairs"]=recorded_pairs.load();
        last_status["recording_lag_seconds"]=double(source_pairs.load()>recorded_pairs.load()?source_pairs.load()-recorded_pairs.load():0)/cfg.rate;
        last_status["recording_queue_high_water_blocks"]=recording_queue.high_water();
        last_status["storage_status_stale"]=false;
    } catch(...) {if(!source_failure)source_failure=std::current_exception();}
    last_status["source_result"]=source_result;
    if(failure){write_json(output/"monitor-status.json",last_status);if(observer.status)observer.status(last_status);std::rethrow_exception(failure);}
    if(source_failure) {
        last_status["state"]="source_error";
        try {std::rethrow_exception(source_failure);} catch(const std::exception& e) {last_status["error"]=e.what();}
        write_json(output/"monitor-status.json",last_status);if(observer.status)observer.status(last_status); std::rethrow_exception(source_failure);
    }
    last_status["source_result"]=source_result;
    write_json(output/"monitor-status.json",last_status);if(observer.status)observer.status(last_status); return last_status;
}
}

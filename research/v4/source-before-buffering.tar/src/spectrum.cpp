#include "signalscope/spectrum.hpp"
#include <kiss_fft.h>
#include <array>
#include <cmath>
#include <numbers>
namespace signalscope {
class Spectrometer::Impl {
public:
    Impl() {plan=kiss_fft_alloc(1024,0,nullptr,nullptr);if(!plan)throw std::bad_alloc();}
    ~Impl(){kiss_fft_free(plan);}
    kiss_fft_cfg plan=nullptr;std::array<kiss_fft_cpx,1024> in{},out{};std::uint64_t sequence=0;
};
Spectrometer::Spectrometer():impl_(std::make_unique<Impl>()){}
Spectrometer::~Spectrometer()=default;
SpectrumFrame Spectrometer::measure(std::span<const std::uint8_t> bytes,std::uint64_t first,std::uint32_t rate,double frequency) {
    SpectrumFrame frame;frame.rate=rate;frame.frequency=frequency;frame.first_sample=first;frame.sequence=++impl_->sequence;
    const auto count=std::min<std::size_t>(1024,bytes.size()/2);
    if(count<16) return frame;
    double window_sum=0,power=0;
    for(std::size_t i=0;i<1024;++i) {
        if(i<count) {
            const double window=.5-.5*std::cos(2*std::numbers::pi*double(i)/double(count-1));window_sum+=window;
            const float re=(float(bytes[i*2])-127.5f)/128,im=(float(bytes[i*2+1])-127.5f)/128;
            impl_->in[i]={static_cast<float>(re*window),static_cast<float>(im*window)};power+=re*re+im*im;
            if(i<128)frame.iq_preview.emplace_back(re,im);
        } else impl_->in[i]={0,0};
    }
    kiss_fft(impl_->plan,impl_->in.data(),impl_->out.data());frame.bins_dbfs.resize(1024);
    for(std::size_t i=0;i<1024;++i) {
        const auto& bin=impl_->out[(i+512)%1024];
        const double value=(double(bin.r)*bin.r+double(bin.i)*bin.i)/(window_sum*window_sum);
        frame.bins_dbfs[i]=static_cast<float>(10*std::log10(std::max(value,1e-14)));
    }
    frame.power_dbfs=10*std::log10(std::max(power/count,1e-14));return frame;
}
}

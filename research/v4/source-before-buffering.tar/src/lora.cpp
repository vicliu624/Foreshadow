#include "signalscope/lora.hpp"
#include <kiss_fft.h>
#include <array>
#include <cmath>
#include <deque>
#include <limits>
#include <numbers>
#include <thread>
#ifdef SIGNALSCOPE_FFTW
#include <fftw3.h>
#endif
#ifdef SIGNALSCOPE_VOLK
#include <volk/volk.h>
#endif

namespace signalscope {
namespace {
struct Peak { int bin=0; double ratio_db=0, concentration=0, power=0,prominence_db=0,narrow_db=0; };
struct WeakSeed {std::uint64_t first=0;Peak a,b;bool active=false;};
struct Frame { std::uint64_t sample=0; Peak up,down; bool down_measured=false; };
struct Track { unsigned count=0; int bin=0; std::uint64_t first=0; bool emitted=false; };
struct Pending {
    std::uint64_t quarter_start=0,pre_start=0,down_start=0;
    double offset=0,up_db=0,down_db=0,power=0,component_power=0;
    bool active=false,needs_refinement=false;
    double down_component=0,sync1_db=0,sync2_db=0,direction_gain_db=0;
};
struct Projection {std::complex<double> value{};double energy=0;double ratio_db() const {return 10*std::log10(std::max(std::norm(value)/std::max(energy,1e-30),1e-30));}};
struct ProjectionKernel {double frequency=0;bool down=false;std::uint64_t used=0;std::vector<std::complex<float>> values;};
struct FineBudgetExceeded {};
class Search {
public:
    Search(const LoRaConfig& c,int sf,bool inverted) : c_(c),sf_(sf),inverted_(inverted) {
        const auto raw=c.rate*std::ldexp(1.0,sf)/c.bandwidth;
        if(std::abs(raw-std::round(raw))>1e-6 || raw<16 || raw>262144)
            throw std::invalid_argument("检测器要求整数符号样本数且不超过 262144；建议 2 MS/s、BW125 kHz");
        n_=static_cast<std::size_t>(std::llround(raw));
        if(n_%c.time_phases) throw std::invalid_argument("符号样本数须能被时间搜索相位数整除");
        hop_=n_/c.time_phases;
        reference_.resize(n_);down_reference_.resize(n_);magnitudes_.resize(n_); in_.resize(n_); out_.resize(n_);
        for(std::size_t i=0;i<n_;++i) {
            const double t=double(i)/c.rate, ts=double(n_)/c.rate;
            const double phase=2*std::numbers::pi*(-c.bandwidth*t/2+c.bandwidth*t*t/(2*ts));
            reference_[i]={static_cast<float>(std::cos(phase)),static_cast<float>(std::sin(phase))};
            down_reference_[i]=std::conj(reference_[i]);
        }
#ifdef SIGNALSCOPE_FFTW
        fast_in_=fftwf_alloc_complex(n_); fast_out_=fftwf_alloc_complex(n_);
        if(!fast_in_ || !fast_out_) { fftwf_free(fast_in_); fftwf_free(fast_out_); throw std::bad_alloc(); }
        fast_plan_=fftwf_plan_dft_1d(static_cast<int>(n_),fast_in_,fast_out_,FFTW_FORWARD,FFTW_ESTIMATE);
        if(!fast_plan_) { fftwf_free(fast_in_); fftwf_free(fast_out_); throw std::bad_alloc(); }
#else
        fft_=kiss_fft_alloc(static_cast<int>(n_),0,nullptr,nullptr);
        if(!fft_) throw std::bad_alloc();
#endif
    }
    ~Search() {
#ifdef SIGNALSCOPE_FFTW
        fftwf_destroy_plan(fast_plan_); fftwf_free(fast_in_); fftwf_free(fast_out_);
#else
        kiss_fft_free(fft_);
#endif
    }
    void reset() {
        samples_={};energies_={};for(auto& history:history_)history.clear();
        kernel_clock_=0;for(auto& kernel:projection_kernels_)kernel.used=0;for(auto& kernel:transition_kernels_)kernel.used=0;
        tracks_.fill({});pending_.fill({});armed_until_.fill(0);preamble_bin_.fill(0);preamble_peak_.fill({});preamble_first_.fill(0);
        preamble_confirmed_.fill(false);weak_seed_={};half_peak_={};have_half_=false;weak_candidates_=weak_accepted_=0;
        fine_attempts_=fine_matches_=projection_points_=fine_budget_exhaustions_=0;projection_limit_=std::numeric_limits<std::uint64_t>::max();
        coarse_pairs_=schedule_rejected_=last_weak_first_=0;
        fine_prefix_passes_=fine_sfd_passes_=fine_sync_passes_=fine_direction_passes_=0;
        last_transition_scores_=Json::array();
        expected_=base_=next_=frame_=active_until_=next_probe_report_=0;fft_count_=fft_points_=cached_neighbors_=0;have_last_=false;
    }
    std::size_t symbol_samples() const {return n_;}
    Json work() const {return {{"bandwidth_hz",c_.bandwidth},{"sf",sf_},{"inverted",inverted_},
        {"fft_count",fft_count_},{"fft_points",fft_points_},{"cached_neighbors",cached_neighbors_},
        {"fine_attempts",fine_attempts_},{"fine_matches",fine_matches_},{"projection_points",projection_points_},
        {"coarse_pairs",coarse_pairs_},{"schedule_rejected",schedule_rejected_},{"last_weak_first_sample",last_weak_first_},
        {"fine_prefix_passes",fine_prefix_passes_},{"fine_sfd_passes",fine_sfd_passes_},
        {"fine_sync_passes",fine_sync_passes_},{"fine_direction_passes",fine_direction_passes_},
        {"last_transition_scores",last_transition_scores_},
        {"fine_budget_exhaustions",fine_budget_exhaustions_},
        {"weak_seed_candidates",weak_candidates_},{"weak_seed_accepted",weak_accepted_}};}
    void feed(std::span<const std::complex<float>> samples,std::span<const double> energies,std::uint64_t base,std::uint64_t first,std::uint64_t end,Json& events,bool collect_probes,bool collect_css) {
        if(first!=expected_)throw std::runtime_error("检测输入不连续，必须重置检测器");
        samples_=samples;energies_=energies;base_=base;expected_=end;collect_css_=collect_css;verify_weak_seed();
        while(next_+n_<=expected_) {
            const auto phase=frame_%c_.time_phases;
            const bool probe=((frame_/c_.time_phases)%c_.probe_stride_symbols)==0;
            bool active=active_until_!=0 && next_<=active_until_;
            if(probe || active) {
                const auto peak=measure(next_,false,n_);
                // 随机 FFT 最大峰在低门限下很常见；只有相邻符号的同频峰
                // 才启动/续期密集搜索。仍从原始历史回填，不漏掉种子之前的前导码。
                bool coherent_seed=false;
                if(trigger(peak) && next_>=base_+n_) {
                    const auto& history=history_[phase];
                    const bool cached=!history.empty() && history.back().sample+n_==next_;
                    if(cached) {
                        ++cached_neighbors_;
                        const auto& previous=history.back().up;
                        coherent_seed=strong(previous) && same(previous.bin,peak.bin);
                    } else {
                        const auto previous=measure(next_-n_,false,n_);
                        coherent_seed=strong(previous) && same(previous.bin,peak.bin);
                    }
                }
                if(probe&&c_.time_phases==2) {
                    if(phase==0){half_peak_=peak;half_sample_=next_;have_half_=true;}
                    else if(have_half_&&half_sample_+hop_==next_&&!weak_seed_.active) {
                        const int difference=(peak.bin-half_peak_.bin+static_cast<int>(n_))%static_cast<int>(n_);
                        const int half=(1<<sf_)/2;
                        Peak paired=peak;
                        bool pair=weak_peak(half_peak_)&&weak_peak(peak)&&std::min(std::abs(difference-half),std::abs(difference-(static_cast<int>(n_)-half)))<=2;
                        if(!pair && weak_peak(half_peak_)) {
                            // 第一窗给出两个可能的半符号移位，只在预测位置回查较弱的第二窗。
                            double best=-300;
                            for(int side:{-1,1}) {
                                const int target=(half_peak_.bin+side*half+static_cast<int>(n_))%static_cast<int>(n_);
                                const auto candidate=measure(next_,false,n_,0,target,2);
                                if(candidate.ratio_db>=std::max(6.,c_.peak_to_mean_db-4)&&candidate.prominence_db>=5&&candidate.narrow_db>=3.5&&candidate.ratio_db>best) {
                                    best=candidate.ratio_db;paired=candidate;pair=true;
                                }
                            }
                        }
                        if(pair){weak_seed_={half_sample_,half_peak_,paired,true};++weak_candidates_;}
                        have_half_=false;verify_weak_seed();active=active_until_!=0&&next_<=active_until_;
                    }
                }
                // 为结构匹配预留结果空间，环境探针不能耗尽离线录制的事件上限。
                if(collect_probes && probe && trigger(peak) && next_>=next_probe_report_ && events.size()<256) {
                    // 只节流诊断输出；下面的种子跟踪和结构检测不跳样。
                    next_probe_report_=next_+std::max<std::uint64_t>(n_,c_.rate/4);
                    events.push_back({{"evidence_level","chirp_probe"},{"sf_candidate",sf_},{"bandwidth_hz",c_.bandwidth},
                        {"first_observed_sample",next_},{"confirmed_at_sample",next_+n_},
                        {"dechirp_peak_offset_hz",(inverted_?-1:1)*signed_bin(peak.bin)*double(c_.rate)/n_},
                        {"peak_to_mean_db",peak.ratio_db},{"iq_inverted",inverted_}});
                }
                if(coherent_seed || active) {
                    // 最后一个前导码后仅需覆盖两个同步符号、两个下 Chirp
                    // 和四分之一结尾；pending 验证独立于密集窗口继续运行。
                    if(coherent_seed)active_until_=std::max(active_until_,next_+5*n_);
                    auto& history=history_[phase];
                    if(history.empty() || history.back().sample+n_!=next_) {
                        const bool provisional=!preamble_confirmed_[phase]&&armed_until_[phase]>=next_;
                        history.clear();tracks_[phase]={};if(!provisional)armed_until_[phase]=0;
                        const auto back=std::min<std::uint64_t>((next_-base_)/n_,c_.repeat_symbols+4);
                        for(auto i=back;i>0;--i)process_frame(next_-i*n_,phase,events,nullptr);
                    }
                    process_frame(next_,phase,events,&peak);
                }
            }
            next_+=hop_;++frame_;verify_pending(events);
        }
        verify_pending(events);
    }
private:
    void process_frame(std::uint64_t sample,std::size_t phase,Json& events,const Peak* measured) {
            auto& history=history_[phase];
            auto& track=tracks_[phase];
            Frame current; current.sample=sample;
            current.up=measured?*measured:measure(sample,false,n_);
            bool armed=armed_until_[phase]!=0 && sample<=armed_until_[phase];
            // 仅在已有前导码证据后运行反向检测，限制无信号时的开销。
            if(armed && (history.empty() || current.sample-history.back().sample==n_)) {
                current.down=measure(sample,true,n_,0,preamble_bin_[phase],1<<sf_,true); current.down_measured=true;
            }
            if(current.down_measured && history.size()>=c_.repeat_symbols+3) {
                const auto& previous=history.back();
                auto previous_down=previous.down;
                if(!preamble_confirmed_[phase] && previous.down_measured && strong(current.down,2)
                        && (!strong(previous_down,2)||!same(current.down.bin,previous_down.bin)))
                    previous_down=measure(previous.sample,true,n_,0,current.down.bin,2);
                // 已有连续前导码后，给下 Chirp 2 dB 泄漏容差；仍验证两个
                // 同频下 Chirp、同步网格、四分之一结尾及其结束。
                const bool previous_candidate=preamble_confirmed_[phase]?strong(previous_down,2):
                    previous_down.ratio_db>=c_.peak_to_mean_db-4&&previous_down.prominence_db>=4;
                if(previous.down_measured && strong(current.down,2) && previous_candidate && same(current.down.bin,previous_down.bin)) {
                    ++coarse_pairs_;
                    const auto sync2=history[history.size()-2].up;
                    const auto sync1=history[history.size()-3].up;
                    const auto pre=history[history.size()-4].up;
                    bool valid=strong(sync1) && strong(sync2) && strong(pre);
                    for(unsigned i=0;i<c_.repeat_symbols;++i) {
                        const auto& item=history[history.size()-4-i].up;
                        valid=valid && strong(item) && same(item.bin,pre.bin);
                    }
                    // 只验证两个同步 Chirp 相对前导码的网格结构，不恢复同步字数值。
                    valid=valid && sync_grid(sync1.bin-pre.bin) && sync_grid(sync2.bin-pre.bin);
                    const double down_hz=signed_bin(current.down.bin)*double(c_.rate)/n_;
                    const auto schedule=[&](const Peak& reference,bool refine){
                        const double up_hz=signed_bin(reference.bin)*double(c_.rate)/n_;
                        const double offset=(up_hz+down_hz)/2;
                        const double shift=(up_hz-down_hz)*n_/(2*c_.bandwidth);
                        const auto down_start=static_cast<std::int64_t>(previous.sample)-static_cast<std::int64_t>(std::llround(shift));
                        if(std::abs(offset)>c_.search_width/2 || std::abs(shift)>double(n_)/2+2 || down_start<0){++schedule_rejected_;return false;}
                        auto& pending=pending_[phase];
                        pending={static_cast<std::uint64_t>(down_start)+2*n_,preamble_first_[phase],
                            static_cast<std::uint64_t>(down_start),offset,reference.ratio_db,current.down.ratio_db,reference.power,reference.power*reference.concentration,true,refine};
                        pending.down_component=current.down.power*current.down.concentration;
                        return true;
                    };
                    if(!valid || !schedule(pre,false))schedule(preamble_peak_[phase],true);
                }
            }
            const auto& peak=current.up;
            if(!strong(peak)) track={};
            else {
                if(!track.count || !same(peak.bin,track.bin)) track={0,peak.bin,sample,false};
                if(track.count<c_.repeat_symbols+1024)++track.count;
                track.bin=peak.bin;
                if(track.count>=c_.repeat_symbols){armed_until_[phase]=sample+6*n_;preamble_bin_[phase]=peak.bin;preamble_peak_[phase]=peak;preamble_first_[phase]=track.first;preamble_confirmed_[phase]=true;}
                if(track.count>=c_.repeat_symbols && !track.emitted) {
                    const double offset=(inverted_?-1:1)*signed_bin(peak.bin)*double(c_.rate)/n_;
                    if(collect_css_ && std::abs(offset)<=c_.search_width/2+c_.bandwidth/2 && events.size()<512)
                        events.push_back({{"evidence_level","css_candidate"},{"sf_candidate",sf_},{"bandwidth_hz",c_.bandwidth},
                            {"first_observed_sample",track.first},{"confirmed_at_sample",sample+n_},
                            {"repeated_chirps",track.count},{"dechirp_peak_offset_hz",offset},
                            {"center_frequency_interval_hz",{c_.receiver_frequency+offset-c_.bandwidth/2,c_.receiver_frequency+offset+c_.bandwidth/2}},
                            {"peak_to_mean_db",peak.ratio_db},{"peak_concentration",peak.concentration},
                            {"fullband_power_dbfs",peak.power>0?Json(10*std::log10(peak.power)):Json(nullptr)},
                            {"iq_inverted",inverted_},{"preamble_direction",inverted_?"down":"up"},
                            {"score_type","uncalibrated_feature_score"},{"needs_lora_structure_validation",true}});
                    track.emitted=true;
                }
            }
            history.push_back(current);
            if(history.size()>c_.repeat_symbols+8) history.pop_front();
    }
    bool strong(const Peak& peak,double margin=0) const { return peak.ratio_db>=c_.peak_to_mean_db-margin && peak.prominence_db>=5; }
    // 稀疏探测使用较强种子，触发后回看历史并按较低结构门限验证。
    // 避免低门限下随机 FFT 峰不断延长全速搜索，拖慢连续采集。
    bool trigger(const Peak& peak) const { return strong(peak) && peak.ratio_db>=std::max(13.0,c_.peak_to_mean_db); }
    bool weak_peak(const Peak& peak) const {return peak.ratio_db>=std::max(6.,c_.peak_to_mean_db-2)&&peak.prominence_db>=5&&peak.narrow_db>=3.5;}
    void verify_weak_seed() {
        if(!weak_seed_.active)return;
        if(weak_seed_.first<base_){weak_seed_.active=false;return;}
        if(weak_seed_.first+2*n_+hop_>expected_)return;
        // 两个半符号峰已给出斜率和位置，第三窗只验证预测峰，避免噪声最大峰挤掉它。
        const auto third=measure(weak_seed_.first+n_,false,n_,0,weak_seed_.a.bin,2);
        const auto consistent=[&](const Peak& peak,int bin){return peak.ratio_db>=std::max(6.,c_.peak_to_mean_db-3)&&peak.prominence_db>=5&&peak.narrow_db>=3.5&&same(peak.bin,bin);};
        const bool phase_a=consistent(third,weak_seed_.a.bin);
        const bool phase_b=phase_a?false:consistent(measure(weak_seed_.first+n_+hop_,false,n_,0,weak_seed_.b.bin,2),weak_seed_.b.bin);
        if(phase_a||phase_b) {
            ++weak_accepted_;last_weak_first_=weak_seed_.first;active_until_=std::max(active_until_,weak_seed_.first+(c_.repeat_symbols+6)*n_);
            for(std::size_t phase=0;phase<2;++phase) {
                if(preamble_confirmed_[phase]&&armed_until_[phase]>=weak_seed_.first)continue;
                const auto& peak=phase?weak_seed_.b:weak_seed_.a;
                const auto first=weak_seed_.first+phase*hop_;
                if(armed_until_[phase]<first||!same(preamble_bin_[phase],peak.bin))preamble_first_[phase]=first;
                else preamble_first_[phase]=std::min(preamble_first_[phase],first);
                armed_until_[phase]=weak_seed_.first+(c_.repeat_symbols+6)*n_;preamble_bin_[phase]=peak.bin;preamble_peak_[phase]=peak;preamble_confirmed_[phase]=false;
            }
        }
        weak_seed_.active=false;
    }
    int signed_bin(int bin) const { return bin>static_cast<int>(n_/2)?bin-static_cast<int>(n_):bin; }
    bool same(int a,int b) const { const auto d=std::abs(a-b); return std::min(d,static_cast<int>(n_)-d)<=2; }
    bool sync_grid(int difference) const {
        const int bins=1<<sf_;
        const int shift=(difference%bins+bins)%bins;
        const int remainder=shift%8;
        return std::min(remainder,8-remainder)<=2;
    }
    Projection project(std::uint64_t first,bool down,double frequency,std::size_t length,std::size_t reference_offset=0) {
        if(length>projection_limit_-projection_points_)throw FineBudgetExceeded{};
        projection_points_+=length;
        const auto* data=samples_.data()+static_cast<std::size_t>(first-base_);
        ProjectionKernel* kernel=nullptr;
        for(auto& item:projection_kernels_)if(!item.values.empty()&&item.frequency==frequency&&item.down==down){kernel=&item;break;}
        if(!kernel) {
            kernel=&*std::min_element(projection_kernels_.begin(),projection_kernels_.end(),[](const auto& a,const auto& b){return a.used<b.used;});
            kernel->values.resize(n_);kernel->frequency=frequency;kernel->down=down;
            const auto step=std::polar(1.0,-2*std::numbers::pi*frequency/c_.rate);std::complex<double> oscillator(1,0);
            for(std::size_t i=0;i<n_;++i){std::complex<double> ref(reference_[i]);if(!down)ref=std::conj(ref);const auto weight=ref*oscillator;kernel->values[i]=static_cast<std::complex<float>>(inverted_?std::conj(weight):weight);oscillator*=step;}
        }
        kernel->used=++kernel_clock_;Projection result;
        const auto* weights=kernel->values.data()+reference_offset;
#ifdef SIGNALSCOPE_VOLK
        std::complex<float> sum;
        volk_32fc_x2_dot_prod_32fc(&sum,data,weights,static_cast<unsigned>(length));result.value=sum;
#else
        for(std::size_t i=0;i<length;++i)result.value+=std::complex<double>(data[i])*std::complex<double>(weights[i]);
#endif
        if(inverted_)result.value=std::conj(result.value);
        result.value*=std::polar(1.0,2*std::numbers::pi*frequency*reference_offset/c_.rate);
        const auto at=static_cast<std::size_t>(first-base_);result.energy=energies_[at+length]-energies_[at];
        return result;
    }
    double normalized_power(int bin) const {
        bin=(bin%static_cast<int>(n_)+static_cast<int>(n_))%static_cast<int>(n_);
        const auto raw=inverted_?(static_cast<int>(n_)-bin)%static_cast<int>(n_):bin;
        return magnitudes_[raw];
    }
    double refined_sync_score(std::uint64_t first,double frequency) {
        const auto dominant=measure(first,false,n_);
        const auto dominant_power=normalized_power(dominant.bin);
        std::array<std::pair<double,double>,8> candidates{};
        const double bin_hz=double(c_.rate)/n_;
        for(int shift=-(1<<sf_);shift<=(1<<sf_);shift+=8) {
            const double f=frequency+shift*bin_hz;
            const int bin=static_cast<int>(std::llround(f/bin_hz));
            const double power=normalized_power(bin-1)+normalized_power(bin)+normalized_power(bin+1);
            auto weakest=std::min_element(candidates.begin(),candidates.end(),[](const auto& a,const auto& b){return a.first<b.first;});
            if(power>weakest->first)*weakest={power,f};
        }
        double best=-300;
        for(const auto& candidate:candidates) {
            if(candidate.first<=0)continue;
            const auto value=project(first,false,candidate.second,n_);
            if(value.ratio_db()<c_.peak_to_mean_db-2 || std::norm(value.value)<dominant_power*.8)continue;
            const int bin=static_cast<int>(std::llround(candidate.second/bin_hz));
            std::array<double,64> background{};const int extent=(1<<sf_)/2;
            for(int i=0;i<32;++i){const int delta=4+(i+1)*(extent-4)/32;background[2*i]=normalized_power(bin+delta);background[2*i+1]=normalized_power(bin-delta);}
            auto upper=background.begin()+48;std::nth_element(background.begin(),upper,background.end());
            if(10*std::log10(std::norm(value.value)/std::max(*upper,1e-30))>=5)best=std::max(best,value.ratio_db());
        }
        return best;
    }
    bool transition_matches(std::uint64_t start,double frequency) {
        last_transition_scores_=Json::array();
        const double bin_hz=double(c_.rate)/n_;
        const int symbols=1<<sf_;
        const auto learn1=project(start,true,frequency,n_),learn2=project(start+n_,true,frequency,n_/2);
        const auto amplitude=(learn1.value+learn2.value*std::polar(1.0,-2*std::numbers::pi*frequency*n_/c_.rate))/(1.5*n_);
        const double amplitude_power=std::norm(amplitude);
        const double noise=std::max((learn1.energy+learn2.energy)/(1.5*n_)-amplitude_power,1e-30);
        double wanted=-std::numeric_limits<double>::infinity(),other=wanted;
        for(int eighths:{15,16,17,18,19,20,24}) {
            const auto length=static_cast<std::size_t>(eighths)*n_/8;
            std::complex<double> down{};
            for(std::size_t at=0;at<length;at+=n_)
                down+=project(start+at,true,frequency,std::min(n_,length-at)).value*std::polar(1.0,-2*std::numbers::pi*frequency*at/c_.rate);
            double score=2*std::real(std::conj(amplitude)*down)-amplitude_power*length;
            // 每个模型解释同一个四符号区间，包含末尾的部分未知上 Chirp。
            for(std::size_t position=length;position<4*n_;position+=n_) {
            const auto first=start+position,count=std::min(n_,4*n_-position);
            measure(first,false,count);
            std::vector<std::complex<float>> corrected(count);
            const auto step=std::polar(1.0,-2*std::numbers::pi*frequency/c_.rate);
            std::complex<double> oscillator(1,0);
            for(std::size_t i=0;i<count;++i) {
                auto value=std::complex<double>(samples_[first-base_+i]);if(inverted_)value=std::conj(value);
                corrected[i]=static_cast<std::complex<float>>(value*oscillator);oscillator*=step;
            }
            std::array<std::pair<double,int>,8> peaks{};
            for(std::size_t bin=0;bin<n_;++bin) {
                auto weakest=std::min_element(peaks.begin(),peaks.end());
                if(normalized_power(static_cast<int>(bin))>weakest->first)*weakest={normalized_power(static_cast<int>(bin)),static_cast<int>(bin)};
            }
            std::vector<int> shifts;
            for(const auto& peak:peaks)for(int delta=-1;delta<=1;++delta) {
                int shift=(static_cast<int>(std::llround(signed_bin(peak.second)-frequency/bin_hz))+delta)%symbols;
                if(shift<0)shift+=symbols;
                if(std::find(shifts.begin(),shifts.end(),shift)==shifts.end())shifts.push_back(shift);
            }
            double up=0;
            for(int shift:shifts) {
                if(count>projection_limit_-projection_points_)throw FineBudgetExceeded{};
                projection_points_+=count;
                const auto numerator=n_*static_cast<std::size_t>(shift);
                const auto offset=numerator/symbols,remainder=numerator%symbols;
                ProjectionKernel* kernel=nullptr;
                for(auto& item:transition_kernels_)if(!item.values.empty()&&item.frequency==double(remainder)){kernel=&item;break;}
                if(!kernel) {
                    kernel=&*std::min_element(transition_kernels_.begin(),transition_kernels_.end(),[](const auto& a,const auto& b){return a.used<b.used;});
                    kernel->frequency=double(remainder);kernel->values.resize(n_);
                    for(std::size_t i=0;i<n_;++i) {
                        const double reference_position=(double(i)+double(remainder)/symbols)/n_;
                        const double phase=2*std::numbers::pi*c_.bandwidth*double(n_)/c_.rate*(-reference_position/2+reference_position*reference_position/2);
                        kernel->values[i]=static_cast<std::complex<float>>(std::polar(1.0,-phase));
                    }
                }
                kernel->used=++kernel_clock_;
                const auto dot=[](const std::complex<float>* a,const std::complex<float>* b,std::size_t count) {
                    if(!count)return std::complex<double>{};
#ifdef SIGNALSCOPE_VOLK
                    std::complex<float> result;volk_32fc_x2_dot_prod_32fc(&result,a,b,static_cast<unsigned>(count));return std::complex<double>(result);
#else
                    std::complex<double> result{};for(std::size_t i=0;i<count;++i)result+=std::complex<double>(a[i])*std::complex<double>(b[i]);return result;
#endif
                };
                const auto split=std::min(count,n_-offset);
                const auto sum=dot(corrected.data(),kernel->values.data()+offset,split)+dot(corrected.data()+split,kernel->values.data(),count-split);
                up=std::max(up,std::abs(sum));
            }
            // 参考幅度由共同的前 1.5 个下 Chirp 估计；对新增未知符号拟合计入惩罚。
            score+=2*std::abs(amplitude)*up-amplitude_power*count-noise*(std::log(double(symbols))+.5*std::log(double(count)));
            }
            last_transition_scores_.push_back({{"down_symbols",eighths/8.0},{"score",score}});
            if(eighths==18)wanted=score;else other=std::max(other,score);
        }
        return wanted>0 && wanted>other+.005*std::abs(other);
    }
    bool refine_alignment(Pending& pending,double& quarter,double& after,bool& transition) {
        ++fine_attempts_;
        const auto radius=static_cast<std::uint64_t>(std::ceil(double(c_.rate)/c_.bandwidth));
        const auto prefix=(c_.repeat_symbols+2)*n_;
        if(pending.down_start<base_+prefix+radius || pending.down_start+4*n_+radius>expected_)return false;
        const auto first=pending.down_start-prefix;
        const auto final_limit=projection_points_+64ULL*1024*1024;
        // 为最终转换验证预留预算，不能被时频候选遍历耗尽。
        projection_limit_=projection_points_+40ULL*1024*1024;
        struct LimitGuard {std::uint64_t& value;~LimitGuard(){value=std::numeric_limits<std::uint64_t>::max();}} guard{projection_limit_};
        bool found=false;double best=-1;Pending selected;double selected_quarter=0,selected_after=0;
        try {
        std::complex<double> covariance{};auto previous=project(first,false,pending.offset,n_).value;
        std::vector<std::complex<double>> coefficients{previous};
        for(unsigned i=1;i<c_.repeat_symbols;++i){const auto next=project(first+i*n_,false,pending.offset,n_).value;covariance+=next*std::conj(previous);previous=next;coefficients.push_back(next);}
        if(std::norm(covariance)<1e-30)return false;
        double fraction=std::arg(covariance)/(2*std::numbers::pi);
        const auto coherent_at=[&](double f){std::complex<double> sum{};for(std::size_t i=0;i<coefficients.size();++i)sum+=coefficients[i]*std::polar(1.0,-2*std::numbers::pi*f*i);return std::norm(sum);};
        double best_fraction=fraction,best_coherence=coherent_at(fraction);
        constexpr double fraction_step=1./64;
        for(int step=-16;step<=16;++step){const double f=fraction+step*fraction_step,score=coherent_at(f);if(score>best_coherence){best_coherence=score;best_fraction=f;}}
        const double left=coherent_at(best_fraction-fraction_step),right=coherent_at(best_fraction+fraction_step);
        const double curvature=left-2*best_coherence+right;
        fraction=best_fraction+(curvature<0?std::clamp(.5*(left-right)/curvature,-1.,1.)*fraction_step:0);
        const double bin_hz=double(c_.rate)/n_;
        const double refined_bin=std::round(pending.offset/bin_hz-fraction)+fraction;
        for(int carrier:{0,-1,1}) {
            const double frequency=(refined_bin+carrier)*bin_hz;
            if(std::abs(frequency)>c_.search_width/2)continue;
            for(int index=0;index<=2*static_cast<int>(radius);++index) {
                const int adjustment=index==0?0:(index%2?-(index+1)/2:index/2);
                const auto down=static_cast<std::uint64_t>(static_cast<std::int64_t>(pending.down_start)+adjustment);
                const auto pre=down-prefix;
                double energy=0,magnitude=0;std::complex<double> coherent{};bool valid=true;
                for(unsigned i=0;i<c_.repeat_symbols;++i){const auto value=project(pre+i*n_,false,frequency,n_);if(value.ratio_db()<c_.peak_to_mean_db-6){valid=false;break;}energy+=value.energy;magnitude+=std::norm(value.value);coherent+=value.value*std::polar(1.0,-2*std::numbers::pi*frequency*n_/c_.rate*i);}
                if(!valid || magnitude<std::pow(10.,c_.peak_to_mean_db/10)*energy || std::norm(coherent)<.8*c_.repeat_symbols*magnitude)continue;
                const double score=std::norm(coherent)/std::max(energy,1e-30);
                // 最终只保留相干得分最高的有效候选；较差候选无需生成同步参考。
                if(score<=best)continue;
                double neighbor=0;
                for(int side:{-4,4}){std::complex<double> sum{};const double f=frequency+side*bin_hz;for(unsigned i=0;i<c_.repeat_symbols;++i)sum+=project(pre+i*n_,false,f,n_).value*std::polar(1.0,-2*std::numbers::pi*f*n_/c_.rate*i);neighbor=std::max(neighbor,std::norm(sum));}
                if(std::norm(coherent)<std::pow(10.,.5)*std::max(neighbor,1e-30))continue;
                ++fine_prefix_passes_;
                const auto down1=project(down,true,frequency,n_),down2=project(down+n_,true,frequency,n_);
                const double d1=down1.ratio_db(),d2=down2.ratio_db();
                if(std::min(d1,d2)<c_.peak_to_mean_db-2)continue;
                const auto quarter_value=project(down+2*n_,true,frequency,n_/4);
                const auto q=quarter_value.ratio_db();
                const auto a=project(down+2*n_+n_/4,true,frequency,n_/4,n_/4).ratio_db();
                if(q<c_.peak_to_mean_db-6)continue;
                const double down_component=(std::norm(down1.value)+std::norm(down2.value))/(2*double(n_)*n_);
                const double quarter_component=std::norm(quarter_value.value)/std::pow(double(n_/4),2);
                if(quarter_component<down_component/16)continue;
                ++fine_sfd_passes_;
                const double sync1=refined_sync_score(down-2*n_,frequency),sync2=refined_sync_score(down-n_,frequency);
                const double sync_mean=10*std::log10((std::pow(10.,sync1/10)+std::pow(10.,sync2/10))/2);
                if(std::min(sync1,sync2)<c_.peak_to_mean_db-2 || sync_mean<c_.peak_to_mean_db-1)continue;
                ++fine_sync_passes_;
                const bool use_transition=true;
                selected=pending;selected.down_start=down;selected.quarter_start=down+2*n_;selected.offset=frequency;
                selected.pre_start=std::min(selected.pre_start,pre);selected.up_db=10*std::log10(magnitude/energy);selected.down_db=std::min(d1,d2);
                selected.power=energy/(c_.repeat_symbols*double(n_));selected.component_power=std::norm(coherent)/std::pow(c_.repeat_symbols*double(n_),2);
                selected.down_component=down_component;
                selected.sync1_db=sync1;selected.sync2_db=sync2;
                best=score;selected_quarter=q;selected_after=a;transition=use_transition;found=true;
            }
        }
        }catch(const FineBudgetExceeded&){++fine_budget_exhaustions_;}
        projection_limit_=final_limit;
        if(found) {
            try {
                double baseline=0;
                for(unsigned i=0;i<c_.repeat_symbols;++i)
                    baseline+=std::pow(10.,project(selected.down_start-prefix+i*n_,true,selected.offset,n_).ratio_db()/10);
                selected.direction_gain_db=selected.down_db-10*std::log10(baseline/c_.repeat_symbols);
                if(selected.direction_gain_db>=5)++fine_direction_passes_;
                found=selected.direction_gain_db>=5 && transition_matches(selected.down_start,selected.offset);
            }
            catch(const FineBudgetExceeded&){++fine_budget_exhaustions_;found=false;}
        }
        if(found){pending=selected;quarter=selected_quarter;after=selected_after;++fine_matches_;}
        return found;
    }
    void verify_pending(Json& events) {
        for(auto& p:pending_) {
            const auto fine_radius=static_cast<std::uint64_t>(std::ceil(double(c_.rate)/c_.bandwidth));
            if(!p.active || p.down_start+4*n_+fine_radius>expected_) continue;
            if(p.quarter_start<base_) { p.active=false; continue; }
            // 最终判定统一验证精细对齐，避免其他 BW/SF 的粗匹配升格。
            double quarter_db=0,after_db=0;bool fine=false,transition=false;
            fine=refine_alignment(p,quarter_db,after_db,transition);
            if(fine && events.size()<1024) {
                Json event={{"evidence_level","lora_structure_match"},{"sf_candidate",sf_},{"bandwidth_hz",c_.bandwidth},
                    {"first_observed_sample",p.pre_start},{"confirmed_at_sample",p.down_start+4*n_+fine_radius},
                    {"sfd_start_sample",p.down_start},{"sfd_end_sample",p.quarter_start+n_/4},
                    {"center_frequency_hz",c_.receiver_frequency+(inverted_?-p.offset:p.offset)},{"frequency_resolution_hz",double(c_.rate)/n_},
                    {"iq_inverted",inverted_},{"preamble_direction",inverted_?"down":"up"},
                    {"preamble_peak_to_mean_db",p.up_db},{"downchirp_peak_to_mean_db",p.down_db},
                    {"downchirp_threshold_db",c_.peak_to_mean_db-2},
                    {"preamble_mean_threshold_db",c_.peak_to_mean_db},
                    {"preamble_symbol_floor_db",c_.peak_to_mean_db-6},
                    {"preamble_coherence_floor",.8},{"quarter_down_threshold_db",c_.peak_to_mean_db-6},
                    {"sync_symbol_floor_db",c_.peak_to_mean_db-2},{"sync_mean_threshold_db",c_.peak_to_mean_db-1},
                    {"sync1_peak_to_mean_db",p.sync1_db},{"sync2_peak_to_mean_db",p.sync2_db},
                    {"down_direction_gain_db",p.direction_gain_db},{"down_direction_gain_floor_db",5},
                    {"fullband_power_dbfs",p.power>0?Json(10*std::log10(p.power)):Json(nullptr)},
                    {"matched_component_dbfs",p.component_power>0?Json(10*std::log10(p.component_power)):Json(nullptr)},
                    {"power_note","Dechirp peak component estimate; timing/leakage may underestimate signal power; not calibrated RF dBm"},
                    {"quarter_down_peak_to_mean_db",quarter_db},{"after_sfd_peak_to_mean_db",after_db},
                    {"fine_synchronization",fine},
                    {"sfd_end_method",transition?"joint_down_to_unknown_up":"quarter_projection_drop"},
                    {"sfd_metric_frequency_window",fine?"phase_refined_carrier_projection":"predicted_center_plus_minus_two_bins"},
                    {"score_type","uncalibrated_structure_score"},{"needs_lora_structure_validation",false},
                    {"evidence",{"重复上 Chirp","两个同步 Chirp 网格","两个完整下 Chirp","四分之一下 Chirp及结束"}},
                    {"protocol","unknown"}};
                const double center=c_.receiver_frequency+(inverted_?-p.offset:p.offset);
                const bool duplicate=have_last_ && std::abs(double(last_down_start_)-p.down_start)<n_/4 && std::abs(last_center_-center)<4*double(c_.rate)/n_;
                if(!duplicate) {events.push_back(std::move(event));have_last_=true;last_down_start_=p.down_start;last_center_=center;}
            }
            p.active=false;
        }
    }
    Peak measure(std::uint64_t first,bool down,std::size_t length,std::size_t reference_offset=0,int target=-1,int radius=0,bool center_constraint=false) {
        ++fft_count_;fft_points_+=n_;
        if(first<base_ || first+length>expected_) throw std::logic_error("检测缓冲索引越界");
        const auto* samples=samples_.data()+static_cast<std::size_t>(first-base_);
        const bool effective_down=down!=inverted_;
#ifdef SIGNALSCOPE_VOLK
        const auto* ref=(effective_down?down_reference_.data():reference_.data())+reference_offset;
        volk_32fc_x2_multiply_conjugate_32fc(reinterpret_cast<lv_32fc_t*>(fast_in_),samples,ref,static_cast<unsigned>(length));
        for(std::size_t i=length;i<n_;++i) {fast_in_[i][0]=0;fast_in_[i][1]=0;}
#else
        for(std::size_t i=0;i<n_;++i) {
            if(i<length) {
                const auto ref=reference_[(i+reference_offset)%n_];
                const float re=samples[i].real(),im=samples[i].imag(),cr=ref.real(),ci=effective_down?ref.imag():-ref.imag();
                in_[i]={re*cr-im*ci,re*ci+im*cr};
            } else in_[i]={0,0};
        }
#endif
#ifdef SIGNALSCOPE_FFTW
#ifndef SIGNALSCOPE_VOLK
        for(std::size_t i=0;i<n_;++i) { fast_in_[i][0]=in_[i].r; fast_in_[i][1]=in_[i].i; }
#endif
        fftwf_execute(fast_plan_);
#else
        kiss_fft(fft_,in_.data(),out_.data());
#endif
        const auto energy_at=static_cast<std::size_t>(first-base_);
        const double total=double(n_)*(energies_[energy_at+length]-energies_[energy_at]);
        double maximum=0; int index=0;
#ifdef SIGNALSCOPE_VOLK
        volk_32fc_magnitude_squared_32f(magnitudes_.data(),reinterpret_cast<const lv_32fc_t*>(fast_out_),static_cast<unsigned>(n_));
        std::uint32_t maximum_index=0;
        volk_32f_index_max_32u(&maximum_index,magnitudes_.data(),static_cast<unsigned>(n_));
        index=static_cast<int>(maximum_index);maximum=magnitudes_[maximum_index];
#else
        for(std::size_t i=0;i<n_;++i) {
#ifdef SIGNALSCOPE_FFTW
            const double value=double(fast_out_[i][0])*fast_out_[i][0]+double(fast_out_[i][1])*fast_out_[i][1];
#else
            const double value=double(out_[i].r)*out_[i].r+double(out_[i].i)*out_[i].i;
#endif
            magnitudes_[i]=static_cast<float>(value);
            if(value>maximum) { maximum=value; index=static_cast<int>(i); }
        }
#endif
        if(target>=0) {
            maximum=0;
            for(int delta=-radius;delta<=radius;++delta){
                const int normalized=(target+delta+static_cast<int>(n_))%static_cast<int>(n_);
                // 上下峰推断的中心须落入搜索窗口，预留两 bin 的量化余量。
                if(center_constraint&&std::abs((signed_bin(normalized)+signed_bin(target))*double(c_.rate)/n_/2)>c_.search_width/2+2*double(c_.rate)/n_)continue;
                const int raw=inverted_?(static_cast<int>(n_)-normalized)%static_cast<int>(n_):normalized;
                if(magnitudes_[raw]>maximum){maximum=magnitudes_[raw];index=raw;}
            }
        }
        std::array<float,64> neighbors{};const int extent=(1<<sf_)/2;
        for(int i=0;i<32;++i){const int delta=4+(i+1)*(extent-4)/32;neighbors[i*2]=magnitudes_[(index+delta)%n_];neighbors[i*2+1]=magnitudes_[(index-delta+static_cast<int>(n_))%n_];}
        auto upper=neighbors.begin()+48;std::nth_element(neighbors.begin(),upper,neighbors.end());
        const double prominence=maximum>0?10*std::log10(maximum/std::max<double>(*upper,1e-30)):0;
        const double near=std::max<double>(magnitudes_[(index+4)%n_],magnitudes_[(index-4+static_cast<int>(n_))%n_]);
        const double narrow=maximum>0?10*std::log10(maximum/std::max(near,1e-30)):0;
        if(inverted_)index=(static_cast<int>(n_)-index)%static_cast<int>(n_);
        return {index,total>0&&maximum>0?10*std::log10(maximum*n_/total):0,total>0?maximum/total:0,total/(double(n_)*length),prominence,narrow};
    }
    LoRaConfig c_; int sf_; bool inverted_;bool collect_css_=true;std::size_t n_=0,hop_=0;
    std::uint64_t fft_count_=0,fft_points_=0,cached_neighbors_=0;
    std::uint64_t fine_attempts_=0,fine_matches_=0,projection_points_=0,fine_budget_exhaustions_=0;
    std::uint64_t coarse_pairs_=0,schedule_rejected_=0,last_weak_first_=0;
    std::uint64_t fine_prefix_passes_=0,fine_sfd_passes_=0,fine_sync_passes_=0,fine_direction_passes_=0;
    Json last_transition_scores_=Json::array();
    std::uint64_t projection_limit_=std::numeric_limits<std::uint64_t>::max();
    std::uint64_t weak_candidates_=0,weak_accepted_=0,half_sample_=0;Peak half_peak_;bool have_half_=false;WeakSeed weak_seed_;
    std::uint64_t next_probe_report_=0;
    kiss_fft_cfg fft_=nullptr;
#ifdef SIGNALSCOPE_FFTW
    fftwf_complex* fast_in_=nullptr;
    fftwf_complex* fast_out_=nullptr;
    fftwf_plan fast_plan_=nullptr;
#endif
    std::vector<std::complex<float>> reference_,down_reference_;
    std::span<const std::complex<float>> samples_;
    std::span<const double> energies_;
    std::array<ProjectionKernel,4> projection_kernels_,transition_kernels_;std::uint64_t kernel_clock_=0;
    std::vector<float> magnitudes_;
    std::vector<kiss_fft_cpx> in_,out_;
    std::array<Track,8> tracks_{};
    std::array<std::deque<Frame>,8> history_{};
    std::array<Pending,8> pending_{};
    std::array<std::uint64_t,8> armed_until_{};
    std::array<int,8> preamble_bin_{};
    std::array<Peak,8> preamble_peak_{};
    std::array<std::uint64_t,8> preamble_first_{};
    std::array<bool,8> preamble_confirmed_{};
    std::uint64_t expected_=0,base_=0,next_=0,frame_=0,active_until_=0;
    bool have_last_=false;std::uint64_t last_down_start_=0;double last_center_=0;
};
}
class LoRaDetector::Impl {
public:
    explicit Impl(const LoRaConfig& c) : config(c) {
        if(c.sf_min<5 || c.sf_max>12 || c.sf_min>c.sf_max || !std::isfinite(c.bandwidth) || c.bandwidth<=0 ||
           c.bandwidth>c.rate || !std::isfinite(c.search_width) || c.search_width<=0 || c.search_width+c.bandwidth>c.rate ||
           !std::isfinite(c.peak_to_mean_db) || c.peak_to_mean_db<6 || c.peak_to_mean_db>60 || c.repeat_symbols<3 || c.repeat_symbols>32 ||
           (c.time_phases!=1 && c.time_phases!=2 && c.time_phases!=4 && c.time_phases!=8) || c.workers<1 || c.workers>4 || (!c.normal_iq && !c.inverted_iq) || c.probe_stride_symbols<1 || c.probe_stride_symbols>4)
            throw std::invalid_argument("LoRa 搜索配置无效");
        const auto widths=c.bandwidth_candidates.empty()?std::vector<double>{c.bandwidth}:c.bandwidth_candidates;
        if(widths.size()>4)throw std::invalid_argument("候选带宽数量超出上限");
        for(std::size_t i=0;i<widths.size();++i) {
            const auto width=widths[i];
            if(!std::isfinite(width) || width<=0 || width+c.search_width>c.rate || std::find(widths.begin(),widths.begin()+static_cast<std::ptrdiff_t>(i),width)!=widths.begin()+static_cast<std::ptrdiff_t>(i))
                throw std::invalid_argument("候选带宽无效、重复或超出采样窗口");
            auto local=c;local.bandwidth=width;local.bandwidth_candidates.clear();
            for(int sf=c.sf_min;sf<=c.sf_max;++sf) {
                if(c.normal_iq)searches.push_back(std::make_unique<Search>(local,sf,false));
                if(c.inverted_iq)searches.push_back(std::make_unique<Search>(local,sf,true));
            }
        }
        // 大 FFT 优先领取，避免固定分组让一个工作线程拖住整块输入。
        std::stable_sort(searches.begin(),searches.end(),[](const auto& a,const auto& b){return a->symbol_samples()>b->symbol_samples();});
        for(const auto& search:searches)history_samples=std::max<std::uint64_t>(history_samples,search->symbol_samples()*(c.repeat_symbols+6));
        const auto count=std::min<std::size_t>(c.workers,searches.size());
        buckets.resize(count,Json::array());
        try {
            for(std::size_t index=0;index<count;++index) workers.emplace_back([this,index]{
                std::uint64_t seen=0;
                for(;;) {
                    std::span<const std::complex<float>> block;std::span<const double> energies; std::uint64_t first=0,base=0,end=0;
                    {
                        std::unique_lock lock(job_mutex);
                        job_ready.wait(lock,[&]{return stopping || generation!=seen;});
                        if(stopping) return;
                        seen=generation;block=job;energies=job_energies;first=job_first;base=raw_base;end=job_end;
                    }
                    try {
                        buckets[index]=Json::array();
                        for(auto search=next_search.fetch_add(1,std::memory_order_relaxed);search<searches.size();search=next_search.fetch_add(1,std::memory_order_relaxed))
                            // 主线程等待全部任务完成后才修改累计 events。
                            searches[search]->feed(block,energies,base,first,end,buckets[index],events.size()<256,events.size()<512);
                    } catch(...) {std::lock_guard lock(job_mutex); if(!job_error) job_error=std::current_exception();}
                    {std::lock_guard lock(job_mutex);++arrived;}
                    job_done.notify_one();
                }
            });
        } catch(...) {shutdown();throw;}
    }
    ~Impl() {shutdown();}
    void shutdown() {
        {std::lock_guard lock(job_mutex);stopping=true;}
        job_ready.notify_all();workers.clear();
    }
    void process(std::span<const std::uint8_t> block,std::uint64_t first) {
        for(std::size_t i=0;i<block.size();i+=2){const std::complex<float> value((float(block[i])-127.5f)/128,(float(block[i+1])-127.5f)/128);raw_samples.push_back(value);raw_energies.push_back(raw_energies.back()+std::norm(value));}
        {
            std::unique_lock lock(job_mutex);job=raw_samples;job_energies=raw_energies;job_first=first;job_end=first+block.size()/2;arrived=0;next_search.store(0,std::memory_order_relaxed);job_error=nullptr;++generation;
            job_ready.notify_all();job_done.wait(lock,[&]{return arrived==workers.size();});
            if(job_error) std::rethrow_exception(job_error);
        }
        for(auto& bucket:buckets) for(auto& event:bucket) {
            const auto level=event.value("evidence_level",std::string());
            const std::size_t limit=level=="chirp_probe"?256:level=="css_candidate"?512:1024;
            if(events.size()<limit)events.push_back(std::move(event));
            else ++omitted_events;
        }
        const auto keep_from=job_end>history_samples?job_end-history_samples:0;
        // 按大块压缩共享历史，避免每个候选模型、每个小块都搬移整个历史。
        if(keep_from>raw_base && keep_from-raw_base>=history_samples) {
            const auto removed=static_cast<std::ptrdiff_t>(keep_from-raw_base);
            raw_samples.erase(raw_samples.begin(),raw_samples.begin()+removed);raw_energies.erase(raw_energies.begin(),raw_energies.begin()+removed);raw_base=keep_from;
            // 有界地重置累计基准，保持长时间运行时的小窗口差分精度。
            if(raw_energies.front()>1000000){const auto baseline=raw_energies.front();for(auto& value:raw_energies)value-=baseline;}
        }
    }
    LoRaConfig config;
    std::uint64_t omitted_events=0;
    std::vector<std::unique_ptr<Search>> searches;
    Json events=Json::array(); std::uint64_t pairs=0;
    std::mutex job_mutex;std::condition_variable job_ready,job_done;
    std::span<const std::complex<float>> job;std::uint64_t job_first=0,job_end=0,generation=0;
    std::span<const double> job_energies;
    std::vector<std::complex<float>> raw_samples;std::uint64_t raw_base=0,history_samples=0;
    std::vector<double> raw_energies{0};
    std::size_t arrived=0;bool stopping=false;std::exception_ptr job_error;
    std::atomic<std::size_t> next_search=0;
    std::vector<Json> buckets;std::vector<std::jthread> workers;
};
LoRaDetector::LoRaDetector(const LoRaConfig& c) : impl_(std::make_unique<Impl>(c)) {}
LoRaDetector::~LoRaDetector()=default;
void LoRaDetector::feed(std::span<const std::uint8_t> bytes,std::uint64_t first) {
    if(bytes.size()%2) throw std::invalid_argument("检测输入存在半个复样本");
    if(first!=impl_->pairs) throw std::runtime_error("检测输入不连续");
    // 限制内部临时缓冲，与上游调用块长度解耦。
    for(std::size_t offset=0;offset<bytes.size();offset+=262144) {
        const auto part=bytes.subspan(offset,std::min<std::size_t>(262144,bytes.size()-offset));
        impl_->process(part,impl_->pairs);
        impl_->pairs+=part.size()/2;
    }
}
Json LoRaDetector::take_events() { Json result=std::move(impl_->events); impl_->events=Json::array(); return result; }
void LoRaDetector::reset() {for(auto& search:impl_->searches)search->reset();impl_->pairs=0;impl_->omitted_events=0;impl_->events=Json::array();impl_->raw_samples.clear();impl_->raw_energies.assign(1,0);impl_->raw_base=0;}
Json LoRaDetector::results() const {
    Json work=Json::array();for(const auto& search:impl_->searches)work.push_back(search->work());
    return {{"algorithm","dechirp-fft-structure-v4"},{"source_pairs",impl_->pairs},{"events",impl_->events},
        {"search_work",std::move(work)},
        {"search_scheduler","dynamic_largest_first"},
        {"probe_reporting_interval_seconds",.25},{"probe_output_is_sampled",true},
        {"result_limit",1024},{"omitted_events",impl_->omitted_events},{"results_at_limit",impl_->events.size()==1024},{"time_phases",impl_->config.time_phases},
        {"workers",impl_->workers.size()},{"probe_stride_symbols",impl_->config.probe_stride_symbols},
        {"bandwidth_candidates_hz",impl_->config.bandwidth_candidates.empty()?std::vector<double>{impl_->config.bandwidth}:impl_->config.bandwidth_candidates},
#ifdef SIGNALSCOPE_FFTW
        {"fft_backend","fftw3f"},
#else
        {"fft_backend","kissfft"},
#endif
#ifdef SIGNALSCOPE_VOLK
        {"vector_backend","volk"},
#else
        {"vector_backend","scalar"},
#endif
        {"limitations",{"得分未校准，未恢复同步字或载荷","每个参考当前仅跟踪最强峰，重叠弱信号可能被遮蔽","尚无实测灵敏度和虚警保证","短时实时验证不代表 24 小时长稳通过"}}};
}
}

#include "analysis_panel.hpp"
#include <algorithm>
#include <cmath>
#include <QApplication>
#include <QComboBox>
#include <QDir>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QLabel>
#include <QProcess>
#include <QProcessEnvironment>
#include <QPushButton>
#include <QScrollArea>
#include <QStandardPaths>
#include <QTemporaryDir>
#include <QTimer>
#include <QVBoxLayout>

class AnalysisPanel::Impl {
public:
    explicit Impl(AnalysisPanel* owner):owner_(owner) {
        auto* layout=new QVBoxLayout(owner);
        auto* tools=new QHBoxLayout;
        zoom_=new QComboBox;zoom_->addItem(QStringLiteral("适应宽度"),0);
        for(int n:{100,150,200})zoom_->addItem(QString::number(n)+"%",n);
        save_=new QPushButton(QStringLiteral("导出研究图"));save_->setEnabled(false);
        cancel_=new QPushButton(QStringLiteral("取消分析"));cancel_->setEnabled(false);
        tools->addWidget(zoom_);tools->addWidget(save_);tools->addWidget(cancel_);tools->addStretch();layout->addLayout(tools);
        status_=new QLabel(QStringLiteral("在录制列表中选择一段 I/Q，然后点击“信号分析”。研究图在后台生成，不修改原始数据。"));status_->setWordWrap(true);layout->addWidget(status_);
        scroll_=new QScrollArea;image_=new QLabel;image_->setAlignment(Qt::AlignTop|Qt::AlignLeft);scroll_->setWidget(image_);layout->addWidget(scroll_,1);
        QObject::connect(zoom_,&QComboBox::currentIndexChanged,owner,[this]{display();});
        QObject::connect(save_,&QPushButton::clicked,owner,[this]{const auto path=QFileDialog::getSaveFileName(owner_,QStringLiteral("导出研究图"),QDir::homePath()+"/LoRa研究图.png","PNG (*.png)");if(!path.isEmpty())original_.save(path);});
        QObject::connect(cancel_,&QPushButton::clicked,owner,[this]{cancelled_=true;const auto pid=process_.processId();process_.terminate();QTimer::singleShot(1500,owner_,[this,pid]{if(process_.state()!=QProcess::NotRunning&&process_.processId()==pid)process_.kill();});});
        QObject::connect(&process_,qOverload<int,QProcess::ExitStatus>(&QProcess::finished),owner,[this](int code,QProcess::ExitStatus state){finished(code,state);});
        QObject::connect(&process_,&QProcess::errorOccurred,owner,[this](QProcess::ProcessError error){if(error==QProcess::FailedToStart){status_->setText(QStringLiteral("无法启动分析程序：")+process_.errorString());cancel_->setEnabled(false);phase_=0;}});
    }
    ~Impl(){cancelled_=true;if(process_.state()!=QProcess::NotRunning){process_.terminate();if(!process_.waitForFinished(500)){process_.kill();process_.waitForFinished(500);}}}
    void launch(const QString& program,QStringList arguments,const QString& output) {
        process_.setStandardOutputFile(output);
        auto environment=QProcessEnvironment::systemEnvironment();
        environment.insert("OPENBLAS_NUM_THREADS","1");environment.insert("OMP_NUM_THREADS","1");environment.insert("MPLBACKEND","Agg");
        process_.setProcessEnvironment(environment);
#ifdef Q_OS_LINUX
        const auto chrt=QStandardPaths::findExecutable("chrt");
        if(!chrt.isEmpty()){arguments.prepend(program);arguments.prepend("0");arguments.prepend("--idle");process_.start(chrt,arguments);return;}
        const auto nice=QStandardPaths::findExecutable("nice");
        if(!nice.isEmpty()){arguments.prepend(program);arguments.prepend("19");arguments.prepend("-n");process_.start(nice,arguments);return;}
#endif
        process_.start(program,arguments);
    }
    void analyze(const QString& metadata) {
        if(process_.state()!=QProcess::NotRunning){status_->setText(QStringLiteral("正在分析上一段录制，请等待或取消。"));return;}
        const auto data=QFileInfo(metadata).dir().filePath("capture.sigmf-data");
        if(QFileInfo(data).size()>64LL*1024*1024){status_->setText(QStringLiteral("研究图当前支持不超过 64 MiB 的 I/Q，请先裁剪较长录制。"));return;}
        if(!temporary_.isValid()){status_->setText(QStringLiteral("无法创建临时分析目录。"));return;}
        metadata_=metadata;cancelled_=false;phase_=1;save_->setEnabled(false);cancel_->setEnabled(true);
        crop_first_=0;crop_pairs_=0;localized_=false;
        original_=QPixmap();image_->clear();status_->setText(QStringLiteral("正在从录制 I/Q 重新检测 LoRa；后台分析不会修改原始文件…"));
        auto executable=QCoreApplication::applicationDirPath()+"/signalscope";
#ifdef Q_OS_WIN
        executable+=".exe";
#endif
        QString detection_input=metadata_;
        // 自动事件已有位置索引，研究只需复核该事件附近的原始样本。
        // 参数仍由 detect 自动搜索；外部无事件索引的录制继续完整检测。
        QFile meta_file(metadata_);
        if(meta_file.open(QIODevice::ReadOnly)&&meta_file.size()<=4*1024*1024) {
            const auto original=QJsonDocument::fromJson(meta_file.readAll()).object();
            const auto global=original.value("global").toObject();
            const auto stored=global.value("signalscope:result").toObject();
            const auto rate=global.value("core:sample_rate").toDouble();
            for(const auto& value:stored.value("events").toArray()) {
                const auto event=value.toObject();
                if(event.value("evidence_level").toString()!="lora_structure_match")continue;
                const auto bw=event.value("bandwidth_hz").toDouble();const auto sf=event.value("sf_candidate").toInt();
                if(global.value("core:datatype").toString()!="cu8"||rate<=0||bw<=0||sf<5||sf>12)break;
                const auto symbol=rate*std::ldexp(1.0,sf)/bw;
                const auto relative=event.value("sfd_start_sample").toDouble()-stored.value("stream_first_sample").toDouble();
                const auto pairs=QFileInfo(data).size()/2;
                if(!std::isfinite(symbol)||symbol<16||symbol>262144||!std::isfinite(relative)||relative<0||relative>=pairs)break;
                const auto n=qint64(std::llround(symbol));
                crop_first_=std::max<qint64>(0,qint64(relative)-12*n);
                crop_pairs_=std::min<qint64>(pairs,qint64(relative)+3*n)-crop_first_;
                QFile input(data),output(temporary_.filePath("crop.sigmf-data"));
                if(!input.open(QIODevice::ReadOnly)||!input.seek(crop_first_*2)||!output.open(QIODevice::WriteOnly|QIODevice::Truncate))break;
                const auto bytes=input.read(crop_pairs_*2);
                if(bytes.size()!=crop_pairs_*2||output.write(bytes)!=bytes.size())break;
                output.close();
                QJsonObject clean_global{{"core:datatype","cu8"},{"core:sample_rate",rate},{"core:version","1.2.6"}};
                auto captures=original.value("captures").toArray();if(captures.isEmpty())break;
                auto capture=captures.first().toObject();capture.insert("core:sample_start",0);capture.remove("core:datetime");
                QJsonObject clean{{"global",clean_global},{"captures",QJsonArray{capture}},{"annotations",QJsonArray{}}};
                detection_input=temporary_.filePath("crop.sigmf-meta");QFile crop_meta(detection_input);
                if(!crop_meta.open(QIODevice::WriteOnly|QIODevice::Truncate)||crop_meta.write(QJsonDocument(clean).toJson())<0){detection_input=metadata_;break;}
                localized_=true;
                status_->setText(QStringLiteral("正在复核录制事件附近的 I/Q；仍自动搜索 BW/SF，原始文件不变…"));
                break;
            }
        }
        if(!localized_){detection_input=metadata_;crop_first_=0;crop_pairs_=0;}
        launch(executable,{"detect","--input",detection_input,"--workers","1","--threshold-db",QString::number(threshold_db_)},temporary_.filePath("detection.json"));
    }
    void finished(int code,QProcess::ExitStatus state) {
        if(cancelled_){status_->setText(QStringLiteral("分析已取消，原始录制已保留。"));phase_=0;cancel_->setEnabled(false);return;}
        if(code!=0||state!=QProcess::NormalExit){status_->setText(QStringLiteral("分析未完成：")+QString::fromUtf8(process_.readAllStandardError().right(3000)));phase_=0;cancel_->setEnabled(false);return;}
        if(phase_==1) {
            QFile file(temporary_.filePath("detection.json"));
            if(!file.open(QIODevice::ReadOnly)||file.size()>4*1024*1024){status_->setText(QStringLiteral("分析结果文件无效或超限。"));phase_=0;cancel_->setEnabled(false);return;}
            auto document=QJsonDocument::fromJson(file.readAll());bool found=false;
            file.close();
            if(localized_) {
                auto result=document.object();QJsonArray shifted;
                for(const auto& value:result.value("events").toArray()) {
                    auto event=value.toObject();
                    for(const auto* key:{"first_observed_sample","confirmed_at_sample","sfd_start_sample","sfd_end_sample"})
                        if(event.contains(key))event.insert(key,event.value(key).toDouble()+crop_first_);
                    shifted.push_back(event);
                }
                result.insert("events",shifted);result.insert("analysis_window_first_sample",double(crop_first_));result.insert("analysis_window_pairs",double(crop_pairs_));
                document=QJsonDocument(result);
                if(!file.open(QIODevice::WriteOnly|QIODevice::Truncate)||file.write(document.toJson())<0){status_->setText(QStringLiteral("研究区间结果写入失败，原始文件未修改。"));phase_=0;cancel_->setEnabled(false);return;}
                file.close();
            }
            for(const auto& item:document.object().value("events").toArray())if(item.toObject().value("evidence_level").toString()=="lora_structure_match"){found=true;break;}
            if(!found){status_->setText(QStringLiteral("未通过 LoRa 前导码结构验证；当前不会把候选绘制成已确认的 LoRa。原始文件未修改。"));phase_=0;cancel_->setEnabled(false);return;}
            QString script;
            const auto directory=QCoreApplication::applicationDirPath();
            for(const auto& candidate:{directory+"/../tools/plot_recording.py",directory+"/../../tools/plot_recording.py",directory+"/../share/signalscope/plot_recording.py"})if(QFileInfo::exists(candidate)){script=candidate;break;}
            auto python=QStandardPaths::findExecutable("python3");if(python.isEmpty())python=QStandardPaths::findExecutable("python");
            if(script.isEmpty()||python.isEmpty()){status_->setText(QStringLiteral("找不到研究绘图脚本或 Python；需要 NumPy、Matplotlib 才能生成研究图。"));phase_=0;cancel_->setEnabled(false);return;}
            phase_=2;status_->setText(QStringLiteral("已找到 LoRa 结构，正在绘制时频图、Dechirp FFT、功率谱及参数…"));
            launch(python,{script,"--input",metadata_,"--analysis",temporary_.filePath("detection.json"),"--output",temporary_.filePath("study.png")},temporary_.filePath("plot-result.json"));return;
        }
        if(phase_==2) {
            original_.load(temporary_.filePath("study.png"));
            if(original_.isNull())status_->setText(QStringLiteral("绘图程序未生成有效图片。"));
            else{display();status_->setText(QStringLiteral("离线研究：")+QFileInfo(metadata_).dir().dirName()+QStringLiteral(" · 显示首个 LoRa 结构事件，可缩放或导出；未解码载荷。"));status_->setToolTip(metadata_);save_->setEnabled(true);}
        }
        phase_=0;cancel_->setEnabled(false);
    }
    void display(){
        if(original_.isNull())return;const int percent=zoom_->currentData().toInt();
        scroll_->setHorizontalScrollBarPolicy(percent?Qt::ScrollBarAsNeeded:Qt::ScrollBarAlwaysOff);
        const int width=percent?original_.width()*percent/100:std::max(100,scroll_->viewport()->width()-5);
        auto pixmap=original_.scaledToWidth(width,Qt::SmoothTransformation);image_->setPixmap(pixmap);image_->resize(pixmap.size());
        if(!percent)QTimer::singleShot(0,owner_,[this,width]{if(!zoom_->currentData().toInt()&&width!=std::max(100,scroll_->viewport()->width()-5))display();});
    }
    AnalysisPanel* owner_;QTemporaryDir temporary_;QProcess process_;QString metadata_;int phase_=0;bool cancelled_=false;double threshold_db_=18;
    qint64 crop_first_=0,crop_pairs_=0;bool localized_=false;
    QLabel *image_,*status_;QScrollArea* scroll_;QComboBox* zoom_;QPushButton *save_,*cancel_;QPixmap original_;
};
AnalysisPanel::AnalysisPanel(QWidget* parent):QWidget(parent),impl_(std::make_unique<Impl>(this)){}
AnalysisPanel::~AnalysisPanel()=default;
void AnalysisPanel::analyze(const QString& metadata){impl_->analyze(metadata);}
void AnalysisPanel::setThreshold(double value){impl_->threshold_db_=value;}
void AnalysisPanel::resizeEvent(QResizeEvent* event){QWidget::resizeEvent(event);impl_->display();}

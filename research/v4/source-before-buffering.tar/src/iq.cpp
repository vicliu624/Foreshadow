#include "signalscope/iq.hpp"
#include <algorithm>
#include <cmath>
#include <ctime>
#include <iomanip>
#include <limits>
#include <sstream>
#include <thread>

namespace signalscope {
void Config::validate() const {
    if (rate < 225001 || rate > 3200000) throw std::invalid_argument("采样率须在 225001–3200000 之间，实际支持仍由驱动检查");
    if (!frequency) throw std::invalid_argument("中心频率必须大于零");
    if (block_bytes < 512 || block_bytes > 4*1024*1024 || block_bytes % 512)
        throw std::invalid_argument("块长度须为 512 的倍数且在 512–4194304 字节内");
    if (!queue_blocks || queue_blocks > 4096 || queue_blocks > (256u*1024u*1024u)/block_bytes)
        throw std::invalid_argument("队列须有界且总容量不超过 256 MiB");
    if (!std::isfinite(seconds) || seconds<0) throw std::invalid_argument("监听时长须为有限非负值，零表示持续监听");
    if (seconds>0) sample_count(seconds, rate);
    if (!std::isfinite(settle_seconds) || settle_seconds < 0 || settle_seconds > 10)
        throw std::invalid_argument("稳定丢弃时长须在 0–10 秒");
}
std::uint64_t sample_count(double seconds, std::uint32_t rate) {
    if (!rate || !std::isfinite(seconds) || seconds <= 0 || seconds > 366*86400.0)
        throw std::invalid_argument("时长须大于零且不超过 366 天，采样率必须非零");
    const auto count = std::floor(seconds * rate);
    if (count < 1) throw std::invalid_argument("时长不足一个复样本");
    return static_cast<std::uint64_t>(count);
}
std::string utc_now() {
    const auto now = std::chrono::system_clock::now();
    const auto t = std::chrono::system_clock::to_time_t(now);
    std::tm tm{};
#ifdef _WIN32
    gmtime_s(&tm, &t);
#else
    gmtime_r(&t, &tm);
#endif
    std::ostringstream out; out << std::put_time(&tm, "%Y-%m-%dT%H:%M:%SZ"); return out.str();
}
void write_json(const std::filesystem::path& path, const Json& j) {
    const auto temp = std::filesystem::path(path.string()+".tmp");
    std::ofstream out(temp, std::ios::binary | std::ios::trunc);
    if (!out) throw std::runtime_error("无法写入元数据: " + temp.string());
    out << j.dump(2) << '\n'; out.close();
    if (!out) throw std::runtime_error("元数据写入失败");
    // 同目录重命名：POSIX 原子替换；Windows 使用备份，失败时恢复旧文件。
#ifdef _WIN32
    auto backup = std::filesystem::path(path.string()+".bak");
    if (std::filesystem::exists(path)) {
        std::filesystem::rename(path, backup);
        try { std::filesystem::rename(temp, path); }
        catch (...) { std::filesystem::rename(backup, path); throw; }
        std::filesystem::remove(backup);
    } else std::filesystem::rename(temp, path);
#else
    std::filesystem::rename(temp, path);
#endif
}
void PowerStats::add(std::span<const std::uint8_t> bytes) {
    if (bytes.size()%2) throw std::invalid_argument("I/Q 数据存在半个复样本");
    for (std::size_t n=0; n<bytes.size(); n+=2) {
        const double i=(double(bytes[n])-127.5)/128.0, q=(double(bytes[n+1])-127.5)/128.0;
        energy+=i*i+q*q; sum_i+=i; sum_q+=q; ++pairs;
        if (bytes[n]==0 || bytes[n]==255 || bytes[n+1]==0 || bytes[n+1]==255) ++clipped_pairs;
    }
}
Json PowerStats::json() const {
    Json j={{"pairs",pairs},{"clipped_pairs",clipped_pairs},{"power_reference","mean |(I+jQ)/128|^2; midpoint=127.5; full input band; not RF dBm"}};
    const auto power = pairs ? energy/double(pairs) : 0;
    j["mean_power_dbfs"] = power>0 ? Json(10*std::log10(power)) : Json(nullptr);
    j["dc_i"] = pairs ? sum_i/double(pairs) : 0;
    j["dc_q"] = pairs ? sum_q/double(pairs) : 0;
    return j;
}
Recorder::Recorder(const std::filesystem::path& dir, const Config& c, const std::string& source) : directory_(dir) {
    c.validate();
    // 原子创建独占目录，防止覆盖与并发写入同一录制。
    if (!std::filesystem::create_directory(dir)) throw std::runtime_error("录制目录已经存在，拒绝覆盖: "+dir.string());
    const auto required=sample_count(c.seconds,c.rate)*2+4*1024*1024;
    if (std::filesystem::space(dir).available<required)
        throw std::runtime_error("磁盘可用空间不足以保存请求时长及安全余量");
    meta_={{"global",{{"core:datatype","cu8"},{"core:sample_rate",c.rate},{"core:version","1.2.6"},
        {"core:recorder","SignalScope 0.1.0"},{"core:description","宽带 I/Q；重放仅限软件分析"},
        {"core:extensions",Json::array({{{"name","signalscope"},{"version","0.1.0"},{"optional",true}}})},
        {"signalscope:source",source},{"signalscope:status","recording"},
        {"signalscope:gain_mode",c.auto_gain?"auto":"manual"},{"signalscope:gain_tenths_db",c.gain_tenths},
        {"signalscope:time_source","host observation; no hardware timestamp"},
        {"signalscope:continuity","unverified"}}},
        {"captures",Json::array()}, {"annotations",Json::array()}};
    data_.open(dir/"capture.sigmf-data",std::ios::binary);
    if (!data_) throw std::runtime_error("无法创建录制数据文件");
    meta_["captures"].push_back({{"core:sample_start",0},{"core:frequency",c.frequency}});
    publish();
}
void Recorder::append(std::span<const std::uint8_t> bytes) {
    if (finished_ || bytes.size()%2) throw std::runtime_error("录制状态或 I/Q 长度错误");
    if (bytes.empty()) return;
    if (!pairs_) meta_["captures"][0]["core:datetime"]=utc_now();
    data_.write(reinterpret_cast<const char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()));
    if (!data_) throw std::runtime_error("I/Q 写入失败，检查磁盘空间");
    pairs_+=bytes.size()/2;
}
void Recorder::publish() { write_json(directory_/"capture.sigmf-meta",meta_); }
void Recorder::annotate(const Json& annotation) { meta_["annotations"].push_back(annotation); }
void Recorder::finish(const std::string& status, const Json& extra) {
    if (finished_) throw std::runtime_error("录制已结束");
    data_.flush(); if (!data_) throw std::runtime_error("I/Q 刷盘失败");
    data_.close(); if (!data_) throw std::runtime_error("I/Q 关闭失败");
    meta_["global"]["signalscope:status"]=status;
    meta_["global"]["signalscope:sample_count"]=pairs_;
    meta_["global"]["signalscope:result"]=extra;
    if (meta_["global"]["signalscope:source"]=="derived-replay") {
        meta_["captures"][0].erase("core:datetime");
        meta_["global"]["signalscope:time_source"]="parent recording sample index; no new RF observation";
    }
    if (meta_["global"]["signalscope:source"].get<std::string>().starts_with("automatic-lora-event")) {
        meta_["captures"][0].erase("core:datetime");
        meta_["global"]["signalscope:time_source"]="stream sample index; save time is not RF arrival time";
        meta_["global"]["signalscope:saved_utc"]=utc_now();
    }
    publish(); finished_=true;
}
Recorder::~Recorder() {
    if (!finished_) { try { finish("interrupted"); } catch (...) {} }
}
ReplayInfo inspect_recording(const std::filesystem::path& path) {
    if (path.extension()!=".sigmf-meta") throw std::runtime_error("须指定 .sigmf-meta 文件");
    if (std::filesystem::file_size(path)>4*1024*1024) throw std::runtime_error("元数据超过 4 MiB 限制");
    std::ifstream in(path); Json j; in >> j;
    const auto& g=j.at("global");
    if (g.at("core:datatype")!="cu8") throw std::runtime_error("当前仅支持交织无符号 8 位复样本 cu8");
    if (g.value("core:num_channels",1)!=1 || g.value("core:offset",0)!=0 || g.value("core:trailing_bytes",0)!=0 || g.contains("core:dataset"))
        throw std::runtime_error("当前不支持多通道、偏移、尾字节或外部 dataset 映射");
    const double rate=g.at("core:sample_rate").get<double>();
    if (!std::isfinite(rate) || rate<1 || rate>100000000 || std::floor(rate)!=rate) throw std::runtime_error("采样率无效或非整数");
    const auto& captures=j.at("captures");
    if (!captures.is_array() || captures.size()!=1 || captures[0].at("core:sample_start")!=0 || captures[0].value("core:header_bytes",0)!=0)
        throw std::runtime_error("当前仅支持从样本零开始的单配置录制，拒绝静默拼接调谐段");
    const double frequency=captures[0].at("core:frequency").get<double>();
    if (!std::isfinite(frequency) || frequency<=0) throw std::runtime_error("中心频率无效");
    auto data=path; data.replace_extension(".sigmf-data");
    const auto size=std::filesystem::file_size(data);
    if (size%2) throw std::runtime_error("数据文件存在半个复样本");
    if (g.contains("signalscope:sample_count") && g.at("signalscope:sample_count")!=size/2)
        throw std::runtime_error("元数据样本数与文件长度不一致");
    return {data,std::move(j),static_cast<std::uint32_t>(rate),frequency,size/2};
}
void replay(const ReplayInfo& info, std::uint64_t first, std::uint64_t count, double speed,
            std::size_t block_bytes, const BlockSink& sink, const std::function<bool()>& cancelled) {
    if (!std::isfinite(speed) || speed<0 || speed>1000 || first>info.pairs || count>info.pairs-first || block_bytes<2 || block_bytes>4*1024*1024 || block_bytes%2)
        throw std::invalid_argument("重放区间、速度或块长度无效");
    std::ifstream in(info.data_path,std::ios::binary);
    if (!in) throw std::runtime_error("无法打开 I/Q 文件");
    in.seekg(static_cast<std::streamoff>(first*2));
    Bytes bytes(block_bytes); std::uint64_t read=0;
    const auto start=std::chrono::steady_clock::now();
    while (read<count && !cancelled()) {
        if (speed>0) {
            const auto deadline=start+std::chrono::duration<double>(double(read)/info.rate/speed);
            while (std::chrono::steady_clock::now()<deadline && !cancelled())
                std::this_thread::sleep_for(std::chrono::milliseconds(2));
            if (cancelled()) break;
        }
        const auto size=static_cast<std::size_t>(std::min<std::uint64_t>(bytes.size(),(count-read)*2));
        in.read(reinterpret_cast<char*>(bytes.data()),static_cast<std::streamsize>(size));
        if (in.gcount()!=static_cast<std::streamsize>(size)) throw std::runtime_error("I/Q 文件在重放期间被截断");
        sink(std::span(bytes.data(),size),first+read); read+=size/2;
    }
}
}

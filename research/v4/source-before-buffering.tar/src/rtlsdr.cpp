#include "signalscope/iq.hpp"
#include <algorithm>
#include <cmath>
#include <exception>
#include <memory>
#include <limits>
#include <thread>
#ifdef SIGNALSCOPE_HAS_RTLSDR
#include <rtl-sdr.h>
#endif

namespace signalscope {
#ifdef SIGNALSCOPE_HAS_RTLSDR
namespace {
void check(int code,const char* operation) {
    if (code<0) throw std::runtime_error(std::string(operation)+" 失败，驱动错误="+std::to_string(code));
}
struct DeviceClose { void operator()(rtlsdr_dev_t* d) const { if(d) rtlsdr_close(d); } };
struct Context {
    rtlsdr_dev_t* device;
    BoundedQueue<Bytes>& queue;
    std::uint64_t discard, target, accepted=0,rejected=0;
    std::atomic<bool> failed{false};
    std::atomic<std::uint64_t> callbacks{0};
    std::atomic<std::int64_t> last_callback{0};
    std::string error;
    Context(rtlsdr_dev_t* d,BoundedQueue<Bytes>& q,std::uint64_t skip,std::uint64_t count)
        : device(d),queue(q),discard(skip),target(count) {}
    static std::int64_t now_ms() {
        return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
    }
    void fail(const char* text) { error=text; failed=true; rtlsdr_cancel_async(device); }
    static void receive(unsigned char* data,std::uint32_t length,void* opaque) noexcept {
        auto& s=*static_cast<Context*>(opaque);
        try {
            ++s.callbacks; s.last_callback=now_ms();
            if (s.failed) return;
            if (length%2) { s.fail("驱动返回半个复样本"); return; }
            const auto drop=std::min<std::uint64_t>(s.discard,length/2);
            s.discard-=drop; data+=drop*2; length-=static_cast<std::uint32_t>(drop*2);
            const auto pairs=std::min<std::uint64_t>(length/2,s.target-s.accepted);
            if (pairs && !s.queue.try_push(Bytes(data,data+pairs*2))) {
                s.rejected+=pairs;
                s.fail("录制队列已满，停止采集；未保存尾部，连续性不可保证"); return;
            }
            s.accepted+=pairs;
            if (s.accepted==s.target) rtlsdr_cancel_async(s.device);
        } catch (...) { s.failed=true; rtlsdr_cancel_async(s.device); }
    }
};
}
Json list_devices() {
    Json result=Json::array();
    for (std::uint32_t n=0;n<rtlsdr_get_device_count();++n) {
        char maker[256]{},product[256]{},serial[256]{};
        const auto status=rtlsdr_get_device_usb_strings(n,maker,product,serial);
        result.push_back({{"index",n},{"name",rtlsdr_get_device_name(n)},{"manufacturer",maker},
            {"product",product},{"serial",serial},{"usb_strings_status",status}});
    }
    return {{"backend","librtlsdr"},{"devices",result}};
}
Json probe_device(std::uint32_t index) {
    rtlsdr_dev_t* raw=nullptr; check(rtlsdr_open(&raw,index),"打开 RTL-SDR");
    std::unique_ptr<rtlsdr_dev_t,DeviceClose> device(raw);
    const auto n=rtlsdr_get_tuner_gains(raw,nullptr);
    if(n<0) throw std::runtime_error("查询增益失败");
    std::vector<int> gains(static_cast<std::size_t>(n));
    if(n && rtlsdr_get_tuner_gains(raw,gains.data())!=n) throw std::runtime_error("增益列表变化");
    return {{"device",index},{"tuner_type",static_cast<int>(rtlsdr_get_tuner_type(raw))},
        {"gain_tenths_db",gains},{"note","驱动枚举信息，不代表实际频段和灵敏度验证"}};
}
Json stream_rtlsdr(const Config& cfg, const BlockSink& sink,const std::function<bool()>& cancelled) {
    cfg.validate();
    rtlsdr_dev_t* raw=nullptr; check(rtlsdr_open(&raw,cfg.device),"打开 RTL-SDR");
    std::unique_ptr<rtlsdr_dev_t,DeviceClose> device(raw);
    check(rtlsdr_set_center_freq(raw,cfg.frequency),"调谐");
    check(rtlsdr_set_sample_rate(raw,cfg.rate),"设置采样率");
    check(rtlsdr_set_tuner_gain_mode(raw,cfg.auto_gain?0:1),"设置增益模式");
    if (!cfg.auto_gain) {
        const int n=rtlsdr_get_tuner_gains(raw,nullptr);
        if (n<=0) throw std::runtime_error("无法查询增益档位");
        std::vector<int> gains(static_cast<std::size_t>(n));
        const auto received=rtlsdr_get_tuner_gains(raw,gains.data());
        if (received!=n || std::find(gains.begin(),gains.end(),cfg.gain_tenths)==gains.end())
            throw std::runtime_error("不支持该手动增益；请通过 probe 查询真实档位");
        check(rtlsdr_set_tuner_gain(raw,cfg.gain_tenths),"设置手动增益");
    }
    const auto actual_rate=rtlsdr_get_sample_rate(raw), actual_frequency=rtlsdr_get_center_freq(raw);
    if (actual_rate!=cfg.rate || actual_frequency!=cfg.frequency)
        throw std::runtime_error("驱动返回采样率或频率与请求不一致，拒绝错误标注录制");
    check(rtlsdr_reset_buffer(raw),"重置 USB 缓冲");
    BoundedQueue<Bytes> queue(cfg.queue_blocks);
    const auto target=cfg.seconds>0?sample_count(cfg.seconds,cfg.rate):std::numeric_limits<std::uint64_t>::max()/2;
    Context context{raw,queue,static_cast<std::uint64_t>(cfg.settle_seconds*cfg.rate),target};
    context.last_callback=Context::now_ms();
    std::atomic<bool> done=false, timed_out=false;
    std::atomic<int> driver_result=0;
    const auto started=std::chrono::steady_clock::now();
    std::jthread acquisition([&]{
        driver_result=rtlsdr_read_async(raw,&Context::receive,&context,0,static_cast<std::uint32_t>(cfg.block_bytes));
        done=true; queue.close();
    });
    std::jthread watchdog([&](std::stop_token stop){
        while(!stop.stop_requested() && !done) {
            const bool stalled=Context::now_ms()-context.last_callback.load()>3000;
            const bool over_budget=cfg.seconds>0 && std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count()>cfg.seconds+cfg.settle_seconds+5;
            if (cancelled() || stalled || over_budget || context.failed) {
                if (stalled || over_budget) timed_out=true;
                rtlsdr_cancel_async(raw);
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(20));
        }
    });
    PowerStats power;double max_sink_seconds=0;
    try {
        Bytes block;
        while(queue.pop(block)) {
            const auto before_sink=std::chrono::steady_clock::now();
            sink(block,power.pairs);
            max_sink_seconds=std::max(max_sink_seconds,std::chrono::duration<double>(std::chrono::steady_clock::now()-before_sink).count());
            power.add(block);
        }
    } catch (...) {
        rtlsdr_cancel_async(raw); acquisition.join(); watchdog.request_stop(); watchdog.join(); throw;
    }
    acquisition.join(); watchdog.request_stop(); watchdog.join();
    Json result={{"backend","librtlsdr"},{"requested_rate_hz",cfg.rate},{"actual_rate_hz",actual_rate},
        {"actual_frequency_hz",actual_frequency},{"actual_gain_tenths_db",rtlsdr_get_tuner_gain(raw)},
        {"callbacks",context.callbacks.load()},{"queue_high_water_blocks",queue.high_water()},
        {"queue_capacity_blocks",cfg.queue_blocks},{"queue_capacity_bytes",cfg.queue_blocks*cfg.block_bytes},
        {"accepted_pairs",context.accepted},{"rejected_pairs",context.rejected},{"max_sink_seconds",max_sink_seconds},
        {"driver_result",driver_result.load()},{"watchdog_timeout",timed_out.load()},
        {"elapsed_seconds",std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count()},
        {"power",power.json()},{"continuity","USB samples have no hardware sequence counter; exact lost sample count unavailable"}};
    const bool complete=power.pairs==context.target;
    if (context.failed || driver_result<0 || timed_out || (!complete && !cancelled())) {
        result["error"]=context.error.empty()?"驱动异常、超时或回调失败":context.error;
        result["status"]="error";
        throw SourceError(result["error"].get<std::string>(),result);
    }
    result["status"]=complete?"complete":"cancelled";
    return result;
}
#else
Json list_devices() { return {{"backend","unavailable"},{"devices",Json::array()},{"reason","此构建未找到 librtlsdr，离线功能仍可使用"}}; }
Json probe_device(std::uint32_t) { throw std::runtime_error("此构建没有 librtlsdr 后端"); }
Json stream_rtlsdr(const Config&,const BlockSink&,const std::function<bool()>&) {
    throw std::runtime_error("此构建没有 librtlsdr 后端，请安装 librtlsdr-dev 后重新配置构建");
}
#endif
Json capture_rtlsdr(const Config& cfg,Recorder& recorder,const std::function<bool()>& cancelled) {
    if(cfg.seconds<=0) throw std::invalid_argument("手动连续录制必须有有限时长；长期监听请使用 monitor");
    try {
        auto result=stream_rtlsdr(cfg,[&](auto bytes,auto){recorder.append(bytes);},cancelled);
        recorder.finish(result["status"].get<std::string>(),result); return result;
    } catch(const SourceError& e) {
        recorder.finish("error",e.details); throw;
    } catch(const std::exception& e) {
        recorder.finish("error",{{"error",e.what()}}); throw;
    }
}
}

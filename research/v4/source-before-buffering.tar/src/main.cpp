#include "signalscope/iq.hpp"
#include "signalscope/lora.hpp"
#include "signalscope/monitor.hpp"
#include <cmath>
#include <csignal>
#include <iostream>
#include <map>
#include <memory>
#include <numbers>
#include <set>

using namespace signalscope;
namespace {
volatile std::sig_atomic_t interrupted=0;
void on_signal(int) { interrupted=1; }
bool cancelled() { return interrupted!=0; }
class Args {
public:
    Args(int argc,char** argv) {
        for(int n=2;n<argc;++n) {
            std::string key=argv[n];
            if(!key.starts_with("--") || n+1==argc || values.contains(key)) throw std::invalid_argument("选项须成对且不重复: "+key);
            values.emplace(key,argv[++n]);
        }
    }
    std::string get(const std::string& key,const std::string& fallback="") { auto it=values.find(key); if(it==values.end()) return fallback; auto v=it->second; values.erase(it); return v; }
    std::string required(const std::string& key) { auto v=get(key); if(v.empty()) throw std::invalid_argument("缺少参数: "+key); return v; }
    double real(const std::string& key,double fallback) {
        auto text=get(key); if(text.empty()) return fallback;
        std::size_t end=0; const auto v=std::stod(text,&end);
        if(end!=text.size() || !std::isfinite(v)) throw std::invalid_argument("无效数值: "+key); return v;
    }
    std::uint64_t integer(const std::string& key,std::uint64_t fallback,std::uint64_t maximum) {
        const auto v=real(key,double(fallback));
        if(v<0 || v>double(maximum) || std::floor(v)!=v) throw std::invalid_argument("整数超出范围: "+key); return static_cast<std::uint64_t>(v);
    }
    void finish() { if(!values.empty()) throw std::invalid_argument("未知参数: "+values.begin()->first); }
private: std::map<std::string,std::string> values;
};
void bandwidths(Args& args,LoRaConfig& config) {
    const auto text=args.get("--bw","all");
    if(text=="all") {config.bandwidth_candidates={125000,250000,500000};return;}
    std::size_t end=0;const auto value=std::stod(text,&end);
    if(end!=text.size() || !std::isfinite(value))throw std::invalid_argument("bw 须为 all 或数值 Hz");
    config.bandwidth=value;
}
Config config(Args& args,double default_seconds=10) {
    Config c;
    c.seconds=default_seconds;
    c.rate=static_cast<std::uint32_t>(args.integer("--rate",c.rate,3200000));
    c.frequency=static_cast<std::uint32_t>(args.integer("--frequency",c.frequency,4294967295ULL));
    c.seconds=args.real("--seconds",c.seconds);
    c.device=static_cast<std::uint32_t>(args.integer("--device",0,1000));
    c.block_bytes=static_cast<std::size_t>(args.integer("--block-bytes",c.block_bytes,4194304));
    c.queue_blocks=static_cast<std::size_t>(args.integer("--queue-blocks",c.queue_blocks,4096));
    c.settle_seconds=args.real("--settle",c.settle_seconds);
    const auto gain=args.get("--gain","19.7");
    c.auto_gain=gain=="auto";
    if(!c.auto_gain) {
        std::size_t end=0; auto g=std::stod(gain,&end);
        if(end!=gain.size() || !std::isfinite(g) || g<-100 || g>100) throw std::invalid_argument("增益无效");
        c.gain_tenths=static_cast<int>(std::lround(g*10));
    }
    c.validate(); return c;
}
void help() {
    std::cout << "SignalScope 0.1.0：采集/录制/离线重放（不发射）\n"
        "  devices\n"
        "  probe [--device 索引]\n"
        "  capture --output 新目录 [--frequency Hz --rate Hz --seconds 秒 --gain dB|auto --device 索引 --settle 秒]\n"
        "  synth --output 新目录 [--frequency Hz --rate Hz --seconds 秒 --tone Hz --amplitude 0..0.95]\n"
        "  inspect --input capture.sigmf-meta\n"
        "  detect --input capture.sigmf-meta [--bw Hz --sf-min 7 --sf-max 12 --search-width Hz --threshold-db 18]\n"
        "  monitor --output 自动事件目录 [--seconds 0 --quota-mib 1024 --max-event-mib 32 --max-event-seconds 8 --keep-hours 0]\n"
        "    可选 --input capture.sigmf-meta 为原速离线验证；实时配置同 capture。预录制仅在内存，不连续写盘。\n"
        "  replay --input capture.sigmf-meta [--start 秒 --duration 秒 --speed 倍速 --output 新目录]\n"
        "speed=0 为尽快处理；默认 1。Ctrl+C 正常停止。cu8 是交织无符号 I/Q。\n";
}
}
int main(int argc,char** argv) {
    std::signal(SIGINT,on_signal); std::signal(SIGTERM,on_signal);
    try {
        if(argc<2 || std::string(argv[1])=="--help") { help(); return 0; }
        const std::string command=argv[1]; Args args(argc,argv);
        if(command=="devices") { args.finish(); std::cout<<list_devices().dump(2)<<'\n'; return 0; }
        if(command=="probe") { const auto index=args.integer("--device",0,1000); args.finish(); std::cout<<probe_device(static_cast<std::uint32_t>(index)).dump(2)<<'\n'; return 0; }
        if(command=="monitor") {
            const auto output=args.required("--output"),input=args.get("--input");
            auto c=config(args,0);
            if(!input.empty()) {
                const auto info=inspect_recording(input); c.rate=info.rate;
                c.frequency=static_cast<std::uint32_t>(info.frequency); c.seconds=double(info.pairs)/info.rate;
            }
            LoRaConfig lc; lc.rate=c.rate; lc.receiver_frequency=c.frequency;
            bandwidths(args,lc);
            lc.sf_min=static_cast<int>(args.integer("--sf-min",7,12));
            lc.sf_max=static_cast<int>(args.integer("--sf-max",12,12));
            lc.search_width=args.real("--search-width",1000000);
            lc.peak_to_mean_db=args.real("--threshold-db",18);
            lc.time_phases=static_cast<unsigned>(args.integer("--time-phases",2,8));
            lc.workers=static_cast<unsigned>(args.integer("--workers",3,4));
            lc.probe_stride_symbols=static_cast<unsigned>(args.integer("--probe-stride",4,4));
            const auto mode=args.get("--iq-mode","both");
            if(mode!="both" && mode!="normal" && mode!="inverted") throw std::invalid_argument("iq-mode 须为 both/normal/inverted");
            lc.normal_iq=mode!="inverted";lc.inverted_iq=mode!="normal";
            RetentionPolicy policy;
            policy.quota_bytes=args.integer("--quota-mib",1024,65536)*1024*1024;
            policy.max_event_bytes=args.integer("--max-event-mib",32,512)*1024*1024;
            policy.ring_bytes=args.integer("--ring-mib",16,128)*1024*1024;
            policy.reserve_bytes=args.integer("--reserve-mib",256,65536)*1024*1024;
            policy.ring_seconds=args.real("--ring-seconds",4);
            policy.pre_seconds=args.real("--pre-seconds",.5);
            policy.post_seconds=args.real("--post-seconds",.5);
            policy.max_event_seconds=args.real("--max-event-seconds",8);
            policy.max_age_hours=args.real("--keep-hours",0);
            policy.max_files=static_cast<std::size_t>(args.integer("--max-files",256,4096));
            policy.diagnostic_candidates=args.integer("--diagnostic",0,1)!=0;
            args.finish(); std::cout<<monitor(c,lc,policy,output,input,cancelled).dump(2)<<'\n'; return cancelled()?130:0;
        }
        if(command=="capture" || command=="synth") {
            const auto output=args.required("--output"); auto c=config(args);
            if(c.seconds<=0) throw std::invalid_argument("手动录制须指定有限正时长，长期事件监听请使用 monitor");
            double tone=0,amplitude=0;
            if(command=="synth") {
                tone=args.real("--tone",200000); amplitude=args.real("--amplitude",0.25);
                if(std::abs(tone)>=c.rate/2.0 || amplitude<0 || amplitude>0.95) throw std::invalid_argument("测试音频偏或幅度无效");
            }
            args.finish();
            Recorder recorder(output,c,command=="synth"?"synthetic-tone":"rtlsdr");
            if(command=="capture") { std::cout<<capture_rtlsdr(c,recorder,cancelled).dump(2)<<'\n'; return cancelled()?130:0; }
            const auto target=sample_count(c.seconds,c.rate); PowerStats stats; Bytes bytes(c.block_bytes);
            while(recorder.pairs()<target && !cancelled()) {
                const auto size=static_cast<std::size_t>(std::min<std::uint64_t>(bytes.size()/2,target-recorder.pairs()));
                for(std::size_t n=0;n<size;++n) {
                    const double phase=2*std::numbers::pi*tone*double(recorder.pairs()+n)/c.rate;
                    bytes[2*n]=static_cast<std::uint8_t>(std::lround(127.5+128*amplitude*std::cos(phase)));
                    bytes[2*n+1]=static_cast<std::uint8_t>(std::lround(127.5+128*amplitude*std::sin(phase)));
                }
                const auto block=std::span(bytes.data(),size*2); recorder.append(block); stats.add(block);
            }
            const auto status=cancelled()?"cancelled":"complete";
            recorder.finish(status,stats.json()); std::cout<<stats.json().dump(2)<<'\n'; return cancelled()?130:0;
        }
        if(command=="detect") {
            const auto info=inspect_recording(args.required("--input"));
            LoRaConfig cfg; cfg.rate=info.rate; cfg.receiver_frequency=info.frequency;
            bandwidths(args,cfg);
            cfg.sf_min=static_cast<int>(args.integer("--sf-min",7,12));
            cfg.sf_max=static_cast<int>(args.integer("--sf-max",12,12));
            cfg.search_width=args.real("--search-width",1000000);
            cfg.peak_to_mean_db=args.real("--threshold-db",18);
            cfg.time_phases=static_cast<unsigned>(args.integer("--time-phases",2,8));
            cfg.workers=static_cast<unsigned>(args.integer("--workers",3,4));
            cfg.probe_stride_symbols=static_cast<unsigned>(args.integer("--probe-stride",4,4));
            const auto mode=args.get("--iq-mode","both");
            if(mode!="both" && mode!="normal" && mode!="inverted") throw std::invalid_argument("iq-mode 须为 both/normal/inverted");
            cfg.normal_iq=mode!="inverted";cfg.inverted_iq=mode!="normal";
            args.finish(); LoRaDetector detector(cfg);
            const auto started=std::chrono::steady_clock::now();
            replay(info,0,info.pairs,0,262144,[&](auto bytes,auto first){ detector.feed(bytes,first); },cancelled);
            auto result=detector.results(); result["source"]="recorded";
            result["cancelled"]=cancelled();
            result["processing_seconds"]=std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count();
            std::cout<<result.dump(2)<<'\n'; return cancelled()?130:0;
        }
        if(command=="inspect" || command=="replay") {
            const auto info=inspect_recording(args.required("--input"));
            if(command=="inspect") {
                args.finish(); std::cout<<Json({{"metadata",info.metadata},{"pairs",info.pairs},{"duration_seconds",double(info.pairs)/info.rate}}).dump(2)<<'\n'; return 0;
            }
            const auto start=args.real("--start",0), duration=args.real("--duration",-1), speed=args.real("--speed",1);
            const auto output=args.get("--output"); args.finish();
            if(start<0 || start>double(info.pairs)/info.rate || (duration!=-1 && duration<=0)) throw std::invalid_argument("重放区间无效");
            const auto first=static_cast<std::uint64_t>(std::floor(start*info.rate));
            const auto count=duration==-1 ? info.pairs-first : sample_count(duration,info.rate);
            if(count>info.pairs-first) throw std::invalid_argument("重放区间超出文件");
            std::unique_ptr<Recorder> recorder;
            if(!output.empty()) {
                Config c; c.rate=info.rate; c.frequency=static_cast<std::uint32_t>(info.frequency);
                c.seconds=double(std::max<std::uint64_t>(count,1))/info.rate;
                const auto& global=info.metadata.at("global");
                c.auto_gain=global.value("signalscope:gain_mode",std::string("auto"))=="auto";
                c.gain_tenths=global.value("signalscope:gain_tenths_db",0);
                recorder=std::make_unique<Recorder>(output,c,"derived-replay");
            }
            PowerStats stats;
            replay(info,first,count,speed,65536,[&](auto bytes,auto){ stats.add(bytes); if(recorder) recorder->append(bytes); },cancelled);
            Json result={{"source","recorded"},{"first_sample",first},{"requested_pairs",count},{"power",stats.json()},
                {"original_status",info.metadata["global"].value("signalscope:status","external")},{"speed",speed}};
            if(recorder) recorder->finish(cancelled()?"cancelled":"complete",{{"parent",std::filesystem::absolute(info.data_path).string()},
                {"parent_first_sample",first},{"note","Derived recording; timestamps are replay observation, not original RF time"},{"analysis",result}});
            std::cout<<result.dump(2)<<'\n'; return cancelled()?130:0;
        }
        throw std::invalid_argument("未知命令: "+command);
    } catch(const std::exception& e) { std::cerr<<"错误："<<e.what()<<'\n'; return 1; }
}

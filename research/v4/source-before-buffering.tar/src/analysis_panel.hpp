#pragma once
#include <QWidget>
#include <memory>
class AnalysisPanel:public QWidget {
public:
    explicit AnalysisPanel(QWidget* parent=nullptr);
    ~AnalysisPanel() override;
    void analyze(const QString& metadata);
    void setThreshold(double value);
protected:
    void resizeEvent(QResizeEvent*) override;
private:
    class Impl;std::unique_ptr<Impl> impl_;
};

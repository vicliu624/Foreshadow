"""跨进程验证真实文件、截断保护、时钟区间与拒绝覆盖；不冒充硬件测试。"""
import json
import pathlib
import subprocess
import sys
import tempfile
import time

exe = sys.argv[1]
def run(*args, ok=True):
    p = subprocess.run([exe, *map(str, args)], capture_output=True, encoding='utf-8')
    assert (p.returncode == 0) == ok, (args, p.returncode, p.stdout, p.stderr)
    return json.loads(p.stdout) if ok else p

with tempfile.TemporaryDirectory(prefix='signalscope-') as d:
    root = pathlib.Path(d)
    original = root / 'original'
    result = run('synth', '--output', original, '--seconds', .05, '--tone', 123456)
    assert result['pairs'] == 100000
    meta = original / 'capture.sigmf-meta'
    data = original / 'capture.sigmf-data'
    payload = data.read_bytes()
    assert len(payload) == 200000
    info = run('inspect', '--input', meta)
    assert info['pairs'] == 100000
    assert info['metadata']['global']['signalscope:status'] == 'complete'
    replay = run('replay', '--input', meta, '--speed', 0, '--output', root/'copy')
    assert replay['power'] == result
    assert (root/'copy/capture.sigmf-data').read_bytes() == payload
    assert 'core:datetime' not in json.loads((root/'copy/capture.sigmf-meta').read_text('utf-8'))['captures'][0]
    run('replay', '--input', meta, '--start', .01, '--duration', .02, '--speed', 0, '--output', root/'slice')
    assert (root/'slice/capture.sigmf-data').read_bytes() == payload[40000:120000]
    run('synth', '--output', original, ok=False)
    assert data.read_bytes() == payload
    run('replay', '--input', meta, '--start', -.1, ok=False)
    run('replay', '--input', meta, '--duration', .06, ok=False)
    run('replay', '--input', meta, '--speed', -1, ok=False)
    run('synth', '--output', root/'bad', '--rate', '2000000oops', ok=False)
    run('synth', '--output', root/'bad', '--seconds', 'nan', ok=False)
    run('synth', '--output', root/'bad', '--unknown', 'x', ok=False)
    assert not (root/'bad').exists()
    damaged = json.loads(meta.read_text('utf-8'))
    damaged['captures'].append({'core:sample_start': 500, 'core:frequency': 480000000})
    meta.write_text(json.dumps(damaged), encoding='utf-8')
    run('inspect', '--input', meta, ok=False)
    damaged['captures'].pop()
    meta.write_text(json.dumps(damaged), encoding='utf-8')
    data.write_bytes(payload[:-2])
    run('inspect', '--input', meta, ok=False)
    data.write_bytes(payload[:-1])
    run('inspect', '--input', meta, ok=False)
print('录制、逐字节重放、裁剪、格式与异常保护通过')

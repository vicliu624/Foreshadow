"""离屏启动真实 GUI 并重放录制；只检查可运行性，布局需另外视觉检查。"""
import hashlib
import os
from pathlib import Path
import subprocess
import sys
import tempfile

gui,cli=sys.argv[1:]
with tempfile.TemporaryDirectory(prefix='signalscope-gui-') as directory:
    root=Path(directory)
    subprocess.run([cli,'synth','--output',str(root/'tone'),'--seconds','.1'],check=True,capture_output=True)
    raw=root/'tone/capture.sigmf-data'
    before=hashlib.sha256(raw.read_bytes()).hexdigest()
    env=dict(os.environ,QT_QPA_PLATFORM='offscreen')
    result=subprocess.run([gui,'--replay',str(root/'tone/capture.sigmf-meta'),'--output',str(root/'events'),
                           '--autostart','--smoke-seconds','2','--screenshot',str(root/'view.png')],env=env,capture_output=True,timeout=30)
    assert result.returncode==0,(result.returncode,result.stderr)
    assert (root/'view.png').read_bytes().startswith(b'\x89PNG\r\n\x1a\n')
    assert hashlib.sha256(raw.read_bytes()).hexdigest()==before,'GUI replay modified original I/Q'
    assert not list((root/'events').glob('**/*.sigmf-data')),'research replay should not duplicate raw I/Q'
print('Qt GUI 离屏启动、录制重放和原始数据保护通过')

"""长稳观察器不能把重启、冻结、丢弃或存储超额判为通过。"""
import importlib.util
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location('soak_receiver', Path(__file__).parents[1]/'tools/soak_receiver.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class SoakValidation(unittest.TestCase):
    def setUp(self):
        self.initial = dict(identity=[1, 'start', 'cli', 'gui'], state='listening', status_age_seconds=1,
                            status_updated_utc='old',
                            source_pairs=100, analysis_lag_seconds=0, recording_lag_seconds=0,
                            disk_refused=0, event_data_bytes=50, quota_bytes=100, max_event_bytes=20,
                            disk_free_bytes=1024**3, **{key: 0 for key in module.COUNTERS})
        self.current = dict(self.initial, source_pairs=200, status_updated_utc='new')

    def test_healthy(self):
        self.assertEqual(module.faults(self.current, self.initial, self.initial), [])
        self.assertEqual(module.faults(self.initial, self.initial, self.initial), [])

    def test_faults(self):
        for change in (
            {'identity': [1, 'new-start', 'cli', 'gui']}, {'state': 'stopped'},
            {'status_age_seconds': 31}, {'source_pairs': 100}, {'analysis_lag_seconds': 3},
            {'recording_lag_seconds': 3}, {'disk_refused': 1}, {'event_data_bytes': 121},
            {'disk_free_bytes': 1}, *({key: 1} for key in module.COUNTERS),
        ):
            with self.subTest(change=change):
                self.assertTrue(module.faults(dict(self.current, **change), self.initial, self.initial))


if __name__ == '__main__':
    unittest.main()

#include "signalscope/iq.hpp"
#include "signalscope/spectrum.hpp"
#include "signalscope/lora.hpp"
#include <cmath>
#include <numbers>
#include <iostream>
#include <future>
#include <thread>
#include <limits>
using namespace signalscope;
void require(bool ok,const char* text) { if(!ok) throw std::runtime_error(text); }
template<class F> void rejects(F f) { bool threw=false; try { f(); } catch(const std::exception&) { threw=true; } require(threw,"expected rejection"); }
int main() {
    try {
        BoundedQueue<int> queue(2);
        require(queue.try_push(1) && queue.try_push(2),"enqueue");
        require(!queue.try_push(3),"overflow must be visible");
        queue.close(); int value=0;
        require(queue.pop(value) && value==1,"FIFO first");
        require(queue.pop(value) && value==2,"FIFO second");
        require(!queue.pop(value) && !queue.try_push(4),"closed queue");
        require(queue.high_water()==2,"high water");
        BoundedQueue<int> waiting(1);
        auto consumer=std::async(std::launch::async,[&]{int v;return waiting.pop(v);});
        waiting.close(); require(!consumer.get(),"close must wake blocked consumer");
        Config config; config.validate();
        config.queue_blocks=0; rejects([&]{config.validate();});
        require(sample_count(.001,2000000)==2000,"exact sample duration");
        require(sample_count(90000,2000000)==180000000000ULL,"more than 24 hours must not overflow");
        Config continuous;continuous.seconds=0;continuous.validate();
        rejects([]{ sample_count(std::numeric_limits<double>::quiet_NaN(),2000000); });
        PowerStats power; const Bytes full={0,255,255,0}; power.add(full);
        require(power.pairs==2 && power.clipped_pairs==2,"clipping");
        rejects([&]{power.add(Bytes{0});});
        Spectrometer spectrum;Bytes tone(2048);
        for(std::size_t n=0;n<1024;++n) {
            const auto phase=2*std::numbers::pi*128*double(n)/1024;
            tone[n*2]=static_cast<std::uint8_t>(std::lround(127.5+32*std::cos(phase)));
            tone[n*2+1]=static_cast<std::uint8_t>(std::lround(127.5+32*std::sin(phase)));
        }
        const auto frame=spectrum.measure(tone,100,2000000,470500000);
        const auto peak=std::max_element(frame.bins_dbfs.begin(),frame.bins_dbfs.end())-frame.bins_dbfs.begin();
        require(peak==640,"spectrum frequency axis must preserve positive frequency");
        require(std::abs(frame.power_dbfs+12.0412)<.15,"digital power normalization");
        LoRaConfig lc;lc.sf_min=lc.sf_max=7;lc.workers=1;
        LoRaDetector detector(lc);detector.feed(tone,0);
        rejects([&]{detector.feed(tone,9999);});
        detector.reset();detector.feed(tone,0);
        require(detector.results()["source_pairs"]==1024,"gap reset must reuse plans and restart sample coordinates");
        std::cout<<"核心契约检查通过\n"; return 0;
    } catch(const std::exception& e) { std::cerr<<e.what()<<'\n'; return 1; }
}

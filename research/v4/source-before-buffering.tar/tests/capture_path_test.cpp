#include "signalscope/monitor.hpp"
#include <iostream>
#include <thread>
using namespace signalscope;
void require(bool value,const char* message){if(!value)throw std::runtime_error(message);}
int main(int argc,char** argv){
    if(argc!=3)return 2;
    try {
        const auto info=inspect_recording(argv[1]);Config cfg;cfg.rate=info.rate;cfg.frequency=static_cast<std::uint32_t>(info.frequency);cfg.queue_blocks=1;
        LoRaConfig lc;lc.rate=cfg.rate;lc.receiver_frequency=cfg.frequency;lc.sf_min=lc.sf_max=7;lc.workers=1;
        RetentionPolicy policy;policy.post_seconds=.01;policy.pre_seconds=.05;
        bool stalled=false;
        MonitorObserver observer;
        observer.status=[&](const Json& state){if(!stalled&&!state.value("recent_lora_events",Json::array()).empty()){stalled=true;std::this_thread::sleep_for(std::chrono::milliseconds(250));}};
        const auto result=monitor(cfg,lc,policy,argv[2],argv[1],[]{return false;},observer);
        require(stalled,"test did not stall analysis after the preamble");
        require(result["analysis_dropped_pairs"].get<std::uint64_t>()>0,"capture must continue while analysis is stalled");
        require(result["capture_pipeline"]=="independent_capture_writer_v3","independent recording path missing");
        require(result["storage"]["completed"].get<unsigned>()>=1,"verified burst was not recorded");
        const auto verify_records=[&](const std::filesystem::path& root){
        std::ifstream original(info.data_path,std::ios::binary);
        for(const auto& item:std::filesystem::directory_iterator(root))if(item.is_directory()&&item.path().filename().string().starts_with("event-")){
            const auto recording=inspect_recording(item.path()/"capture.sigmf-meta");
            const auto& saved=recording.metadata["global"]["signalscope:result"];
            require(recording.metadata["global"]["signalscope:status"]!="analysis_gap","analysis gap must not split captured raw I/Q");
            const auto first=saved["stream_first_sample"].get<std::uint64_t>();
            Bytes expected(static_cast<std::size_t>(recording.pairs*2)),actual(expected.size());
            original.clear();original.seekg(static_cast<std::streamoff>(first*2));original.read(reinterpret_cast<char*>(expected.data()),static_cast<std::streamsize>(expected.size()));
            std::ifstream copied(recording.data_path,std::ios::binary);copied.read(reinterpret_cast<char*>(actual.data()),static_cast<std::streamsize>(actual.size()));
            require(actual==expected,"recorded raw I/Q must be byte-exact despite analysis backpressure");
            require(saved["quiet_tail_observed"]==true,"quiet tail was not retained");
        }};
        verify_records(argv[2]);
        cfg.queue_blocks=64;
        std::atomic<bool> writer_stalled=false,writer_waiting=false,analysis_advanced=false;
        MonitorObserver slow_writer;
        slow_writer.recording_progress=[&](std::uint64_t){
            if(!writer_stalled.exchange(true)){
                writer_waiting=true;std::this_thread::sleep_for(std::chrono::milliseconds(750));writer_waiting=false;
            }
        };
        slow_writer.status=[&](const Json& state){
            if(writer_waiting&&state.value("processed_pairs",0ULL)>=info.pairs)analysis_advanced=true;
        };
        const std::filesystem::path slow_root=std::string(argv[2])+"-slow-writer";
        const auto writer_result=monitor(cfg,lc,policy,slow_root,argv[1],[]{return false;},slow_writer);
        require(writer_stalled&&analysis_advanced,"analysis did not advance during writer stall");
        require(writer_result["analysis_dropped_pairs"]==0,"writer stall must not discard analysis input");
        require(writer_result["recording_queue_high_water_blocks"].get<unsigned>()>1,"writer stall did not exercise bounded backlog");
        require(writer_result["recording_processed_pairs"]==writer_result["source_pairs"],"writer did not drain all accepted raw input");
        require(writer_result["storage"]["completed"].get<unsigned>()>=1,"writer-stalled burst was not saved");
        verify_records(slow_root);
        MonitorObserver broken_writer;
        broken_writer.recording_progress=[](std::uint64_t){throw std::runtime_error("injected recording failure");};
        for(int attempt=0;attempt<5;++attempt){
        const std::filesystem::path broken_root=std::string(argv[2])+"-failed-writer-"+std::to_string(attempt);
        bool failed=false;
        try {monitor(cfg,lc,policy,broken_root,argv[1],[]{return false;},broken_writer);}
        catch(const std::runtime_error& error){failed=std::string(error.what())=="injected recording failure";}
        require(failed,"recording failure did not propagate or stop cleanly");
        std::ifstream failure_file(broken_root/"monitor-status.json");Json failure_status;failure_file>>failure_status;
        require(failure_status["state"]=="source_error","recording failure not persisted as source_error");
        }
        std::cout<<"分析与录制阻塞隔离通过：原始 I/Q 连续、逐字节一致，写盘路径停顿不阻塞分析\n";return 0;
    }catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}
}
